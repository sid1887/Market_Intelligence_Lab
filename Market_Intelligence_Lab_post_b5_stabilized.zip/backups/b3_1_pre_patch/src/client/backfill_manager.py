import time
import os
import datetime
from typing import List, Dict, Any, Optional, Tuple, Set
from src.storage.database import DatabaseManager
from src.client.nse_mcp_client import NseMcpClient
from src.client.validator import RecordValidator

class BackfillManager:
    """
    Orchestrates historical multi-stock backfilling for universe constituents.
    Skips already-backfilled stocks, validates invariants, enforces session affinity,
    and records audit logs without corrupting Phase 1 data.
    """

    def __init__(
        self,
        db: DatabaseManager,
        mcp_client: Optional[NseMcpClient] = None,
        min_required_records: int = 480
    ):
        self.db = db
        self.mcp_client = mcp_client or NseMcpClient()
        self.validator = RecordValidator()
        self.min_required_records = min_required_records

    def verify_symbol_coverage(self, symbol: str) -> Dict[str, Any]:
        """Checks actual post-ingestion coverage for a symbol against acceptance criteria."""
        with self.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT COUNT(*), MIN(trading_date), MAX(trading_date) FROM ohlcv_daily WHERE symbol = ? AND series = 'EQ'",
                (symbol,)
            )
            count, min_date, max_date = cursor.fetchone()

        meets_target = count >= self.min_required_records
        return {
            "symbol": symbol,
            "session_count": count,
            "earliest_date": min_date,
            "latest_date": max_date,
            "target": self.min_required_records,
            "meets_target": meets_target
        }

    def get_active_universe(self) -> List[str]:
        """Returns the authoritative list of active symbols from securities_master."""
        with self.db.get_connection() as conn:
            cursor = conn.execute(
                "SELECT symbol FROM securities_master WHERE is_active = 1 ORDER BY symbol"
            )
            return [row[0] for row in cursor.fetchall()]

    def get_symbols_needing_backfill(self, symbols: List[str]) -> List[str]:
        """Identifies symbols with fewer than min_required_records in ohlcv_daily."""
        needing_backfill = []
        with self.db.get_connection() as conn:
            for sym in symbols:
                cursor = conn.execute(
                    "SELECT COUNT(*) FROM ohlcv_daily WHERE symbol = ? AND series = 'EQ'",
                    (sym,)
                )
                cnt = cursor.fetchone()[0]
                if cnt < self.min_required_records:
                    needing_backfill.append(sym)
        return needing_backfill

    def backfill_symbol(
        self,
        symbol: str,
        total_months: int = 24,
        end_date: str = "2026-10-23"
    ) -> Dict[str, Any]:
        """
        Backfills a single symbol using chunked MCP calls and persists validated records.
        """
        self.validator.reset_dedup()
        t0 = time.time()

        try:
            raw_records, raw_path = self.mcp_client.fetch_stock_history_chunked(
                symbol=symbol,
                total_months=total_months,
                end_date=end_date
            )
        except Exception as e:
            return {
                "symbol": symbol,
                "status": "FAILED",
                "error": f"MCP fetch error: {str(e)}",
                "records_upserted": 0,
                "duration_seconds": round(time.time() - t0, 2)
            }

        accepted, rejected, summary = self.validator.validate_batch(raw_records, source="nse_mcp")
        upserted_count = self.db.upsert_ohlcv_records(accepted)

        # Audit logging
        now_ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
        date_start = accepted[0]["trading_date"] if accepted else None
        date_end = accepted[-1]["trading_date"] if accepted else None

        self.db.record_audit_log(
            source="nse_mcp",
            endpoint="https://mcp.nseindia.in/bhavcopy/cm/mcp",
            symbol=symbol,
            date_range_start=date_start,
            date_range_end=date_end,
            records_retrieved=summary["total_input"],
            records_accepted=summary["accepted_count"],
            records_rejected=summary["rejected_count"],
            validation_summary=summary,
            raw_payload_path=raw_path,
            status="SUCCESS" if summary["accepted_count"] > 0 else "PARTIAL",
            created_at=now_ts
        )

        return {
            "symbol": symbol,
            "status": "SUCCESS",
            "records_retrieved": summary["total_input"],
            "records_upserted": upserted_count,
            "records_rejected": summary["rejected_count"],
            "date_range": f"{date_start} to {date_end}",
            "duration_seconds": round(time.time() - t0, 2)
        }

    def backfill_universe(
        self,
        symbols: List[str],
        total_months: int = 24,
        end_date: str = "2026-10-23",
        max_symbols: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Backfills symbols needing data.
        """
        to_process = self.get_symbols_needing_backfill(symbols)
        if max_symbols:
            to_process = to_process[:max_symbols]

        results = []
        total_upserted = 0

        for idx, sym in enumerate(to_process, 1):
            res = self.backfill_symbol(sym, total_months=total_months, end_date=end_date)
            results.append(res)
            total_upserted += res.get("records_upserted", 0)
            time.sleep(0.1)  # Gentle spacing between symbols

        return {
            "total_requested": len(symbols),
            "needed_backfill": len(to_process),
            "completed_count": len([r for r in results if r["status"] == "SUCCESS"]),
            "failed_count": len([r for r in results if r["status"] == "FAILED"]),
            "total_records_upserted": total_upserted,
            "details": results
        }
