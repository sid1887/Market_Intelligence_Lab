-- ====================================================================
-- Market Intelligence Lab: Phase 3 / Milestone B5 Schema Migration (v3.0)
-- Safe, additive migration for Evidence Records and Movement Explanations.
-- ====================================================================

-- 1. Unified Evidence Records
CREATE TABLE IF NOT EXISTS evidence_records (
    evidence_id TEXT PRIMARY KEY,
    symbol TEXT NOT NULL,
    entity_type TEXT NOT NULL,               -- 'STOCK', 'SECTOR', 'BENCHMARK', 'MACRO'
    event_date TEXT NOT NULL,                -- YYYY-MM-DD
    broadcast_timestamp TEXT DEFAULT NULL,   -- ISO 8601 IST
    effective_session_date TEXT NOT NULL,    -- Aligned t=0 trading session YYYY-MM-DD
    evidence_tier INTEGER NOT NULL,          -- 1, 2, 3, 4, 5
    evidence_category TEXT NOT NULL,         -- 'EARNINGS_RELEASE', 'DIVIDEND_DECLARATION', etc.
    evidence_direction TEXT NOT NULL,        -- 'POSITIVE', 'NEGATIVE', 'NEUTRAL', 'AMBIGUOUS'
    headline TEXT NOT NULL,
    details_json TEXT NOT NULL,              -- JSON string with domain attributes
    source_identity TEXT NOT NULL,           -- e.g. 'nse_circular', 'bse_disclosure', 'cfs_table'
    source_reference TEXT DEFAULT NULL,      -- URL or document identifier
    verification_status TEXT NOT NULL DEFAULT 'PENDING_VERIFICATION', -- 'VERIFIED', 'PENDING_VERIFICATION', 'UNVERIFIED'
    is_pit_eligible INTEGER NOT NULL DEFAULT 1, -- 1=Point-in-time safe, 0=Lookahead hazard
    reporting_basis TEXT DEFAULT NULL,       -- 'CONSOLIDATED', 'STANDALONE', NULL
    expectation_surprise TEXT NOT NULL DEFAULT 'UNKNOWN', -- 'BEAT', 'MISS', 'IN_LINE', 'UNKNOWN'
    is_contradictory INTEGER NOT NULL DEFAULT 0, -- 1=Contradicts observed price action
    retrieval_timestamp TEXT NOT NULL,       -- ISO 8601 UTC
    created_at TEXT NOT NULL                 -- ISO 8601 UTC
);

CREATE INDEX IF NOT EXISTS idx_evidence_sym_session 
ON evidence_records(symbol, effective_session_date);

CREATE INDEX IF NOT EXISTS idx_evidence_session 
ON evidence_records(effective_session_date);

CREATE INDEX IF NOT EXISTS idx_evidence_tier 
ON evidence_records(evidence_tier);

-- 2. Movement Explanations Cache / Ledger
CREATE TABLE IF NOT EXISTS movement_explanations (
    explanation_id TEXT PRIMARY KEY,
    symbol TEXT NOT NULL,
    trading_date TEXT NOT NULL,              -- YYYY-MM-DD
    movement_classification TEXT NOT NULL,   -- 'IDIOSYNCRATIC_OUTPERFORMANCE', etc.
    stock_return_1d REAL NOT NULL,
    benchmark_return_1d REAL DEFAULT NULL,
    sector_return_1d REAL DEFAULT NULL,
    sector_benchmark_type TEXT NOT NULL,     -- 'OFFICIAL_SECTOR_PRI', 'SYNTHETIC_PEER_BASKET', etc.
    sector_benchmark_name TEXT NOT NULL,     -- e.g. 'NIFTY IT', 'SYNTHETIC_ENERGY_BASKET'
    abnormal_return REAL DEFAULT NULL,
    sector_adjusted_return REAL DEFAULT NULL,
    volume_ratio REAL DEFAULT NULL,
    primary_evidence_id TEXT DEFAULT NULL,
    evidence_strength_score REAL NOT NULL,   -- 0 to 100 deterministic heuristic score
    confidence_level TEXT NOT NULL,          -- 'HIGH_CONFIDENCE', 'MODERATE_CONFIDENCE', etc.
    is_contradicted INTEGER NOT NULL DEFAULT 0,
    contradiction_penalty REAL NOT NULL DEFAULT 0.0,
    unexplained_residual_pct REAL DEFAULT NULL,
    full_report_json TEXT NOT NULL,          -- Structured JSON of complete investigation
    generated_at TEXT NOT NULL               -- ISO 8601 UTC
);

CREATE INDEX IF NOT EXISTS idx_explanation_sym_date 
ON movement_explanations(symbol, trading_date);
