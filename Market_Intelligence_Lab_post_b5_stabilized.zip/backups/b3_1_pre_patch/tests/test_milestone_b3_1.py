import unittest
import sqlite3
import os
from src.storage.database import DatabaseManager
from src.client.index_client import IndexClient

class TestMilestoneB31(unittest.TestCase):
    """
    Validation test suite for Milestone B3.1:
    - 24-month historical market data (>= 480 sessions) for all 50 Nifty 50 constituents.
    - 8 Sectoral Indices ingested for both PRI and TRI (>= 480 sessions each).
    - Zero TRI OHLC fabrication: open, high, low must be strictly NULL.
    - Financial price invariants: High >= Low, High >= Open/Close, Low <= Open/Close.
    - Ingestion audit logging completeness.
    """

    DB_PATH = "data/market_lab.db"

    @classmethod
    def setUpClass(cls):
        if not os.path.exists(cls.DB_PATH):
            raise unittest.SkipTest(f"Database {cls.DB_PATH} not found.")
        cls.db = DatabaseManager(cls.DB_PATH)

    def test_sectoral_indices_presence_and_depth(self):
        """Verify all 8 sectoral indices + Nifty 50 exist in index_daily with >= 480 records for both PRI and TRI."""
        expected_indices = [
            "NIFTY 50",
            "NIFTY BANK",
            "NIFTY IT",
            "NIFTY AUTO",
            "NIFTY FMCG",
            "NIFTY PHARMA",
            "NIFTY METAL",
            "NIFTY FINANCIAL SERVICES",
            "NIFTY REALTY"
        ]

        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            for idx_name in expected_indices:
                # Check PRI
                cursor.execute(
                    "SELECT COUNT(*), MIN(trading_date), MAX(trading_date) FROM index_daily WHERE index_name = ? AND index_type = 'PRI'",
                    (idx_name,)
                )
                pri_count, pri_min, pri_max = cursor.fetchone()
                self.assertGreaterEqual(pri_count, 480, f"PRI records for {idx_name} is {pri_count} < 480")
                self.assertLessEqual(pri_min, "2024-10-25")
                self.assertGreaterEqual(pri_max, "2026-10-23")

                # Check TRI
                cursor.execute(
                    "SELECT COUNT(*), MIN(trading_date), MAX(trading_date) FROM index_daily WHERE index_name = ? AND index_type = 'TRI'",
                    (idx_name,)
                )
                tri_count, tri_min, tri_max = cursor.fetchone()
                self.assertGreaterEqual(tri_count, 480, f"TRI records for {idx_name} is {tri_count} < 480")
                self.assertLessEqual(tri_min, "2024-10-25")
                self.assertGreaterEqual(tri_max, "2026-10-23")

    def test_zero_tri_ohlc_fabrication(self):
        """Enforce strict financial invariant: TRI records MUST have open, high, and low as NULL."""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COUNT(*) FROM index_daily 
                WHERE index_type = 'TRI' 
                  AND (open IS NOT NULL OR high IS NOT NULL OR low IS NOT NULL)
            """)
            fabricated_tri_count = cursor.fetchone()[0]
            self.assertEqual(fabricated_tri_count, 0, f"Found {fabricated_tri_count} TRI records with fabricated OH&L values!")

            cursor.execute("SELECT COUNT(*) FROM index_daily WHERE index_type = 'TRI' AND close IS NULL")
            null_tri_close = cursor.fetchone()[0]
            self.assertEqual(null_tri_close, 0, f"Found {null_tri_close} TRI records with NULL close!")

    def test_pri_price_invariants(self):
        """Enforce standard financial price invariants on index_daily PRI records."""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            # Non-positive prices
            cursor.execute("""
                SELECT COUNT(*) FROM index_daily 
                WHERE index_type = 'PRI' 
                  AND (open <= 0 OR high <= 0 OR low <= 0 OR close <= 0)
            """)
            self.assertEqual(cursor.fetchone()[0], 0, "Found non-positive index PRI prices")

            # High < Low
            cursor.execute("""
                SELECT COUNT(*) FROM index_daily 
                WHERE index_type = 'PRI' AND high < low
            """)
            self.assertEqual(cursor.fetchone()[0], 0, "Found index PRI records where High < Low")

            # High < Open or High < Close
            cursor.execute("""
                SELECT COUNT(*) FROM index_daily 
                WHERE index_type = 'PRI' 
                  AND (high < open - 0.05 OR high < close - 0.05)
            """)
            self.assertEqual(cursor.fetchone()[0], 0, "Found index PRI records where High is less than Open/Close")

    def test_constituent_ohlcv_invariants(self):
        """Verify that all ohlcv_daily records obey fundamental invariants."""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT COUNT(*) FROM ohlcv_daily 
                WHERE open <= 0 OR high <= 0 OR low <= 0 OR close <= 0
            """)
            self.assertEqual(cursor.fetchone()[0], 0, "Found non-positive equity prices")

            cursor.execute("SELECT COUNT(*) FROM ohlcv_daily WHERE high < low")
            self.assertEqual(cursor.fetchone()[0], 0, "Found equity records where High < Low")

            cursor.execute("SELECT COUNT(*) FROM ohlcv_daily WHERE volume < 0")
            self.assertEqual(cursor.fetchone()[0], 0, "Found equity records with negative volume")

    def test_audit_logging_presence(self):
        """Verify ingestion audit logs are recorded for indices and constituents."""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM ingestion_audit_log WHERE source = 'nifty_indices_archive'")
            index_audit_count = cursor.fetchone()[0]
            self.assertGreaterEqual(index_audit_count, 16, f"Expected at least 16 index audit logs, found {index_audit_count}")

            cursor.execute("SELECT COUNT(*) FROM ingestion_audit_log WHERE source = 'nse_mcp'")
            stock_audit_count = cursor.fetchone()[0]
            self.assertGreaterEqual(stock_audit_count, 50, f"Expected at least 50 stock audit logs, found {stock_audit_count}")

    def test_constituents_depth_requirement(self):
        """
        Verify that all 50 constituents in ohlcv_daily have at least 480 records.
        """
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT symbol, COUNT(*) 
                FROM ohlcv_daily 
                WHERE series = 'EQ' 
                GROUP BY symbol 
                HAVING COUNT(*) < 480
            """)
            insufficient = cursor.fetchall()
            self.assertEqual(
                len(insufficient), 0,
                f"Symbols with fewer than 480 records: {insufficient}"
            )

            cursor.execute("SELECT COUNT(DISTINCT symbol) FROM ohlcv_daily WHERE series = 'EQ'")
            total_symbols = cursor.fetchone()[0]
            self.assertEqual(total_symbols, 50, f"Expected 50 symbols, found {total_symbols}")

if __name__ == "__main__":
    unittest.main()
