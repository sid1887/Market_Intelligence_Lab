import os
import json
import datetime
from typing import Dict, Any, List, Optional, Tuple

from src.storage.database import DatabaseManager
from src.client.validator import RecordValidator
from src.quant.fundamentals import FundamentalsEngine

class FundamentalsClient:
    """
    Ingestion, validation, and daily factor computation client for company financial statements
    and fundamental valuation metrics.
    """

    def __init__(
        self,
        db_manager: DatabaseManager,
        validator: Optional[RecordValidator] = None,
        engine: Optional[FundamentalsEngine] = None
    ):
        self.db = db_manager
        self.validator = validator or RecordValidator()
        self.engine = engine or FundamentalsEngine(db_manager=self.db)

    def ingest_financial_statements(
        self,
        raw_statements: List[Dict[str, Any]],
        source: str = "exchange_filings"
    ) -> Dict[str, Any]:
        """
        Validates and upserts financial statement records into SQLite.
        Logs an audit record to ingestion_audit_log upon completion.
        """
        if not raw_statements:
            return {"accepted": 0, "rejected": 0, "total": 0}

        retrieval_ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
        accepted, rejected, summary = self.validator.validate_financial_statements_batch(
            raw_statements,
            retrieval_timestamp=retrieval_ts
        )

        inserted_count = 0
        if accepted:
            inserted_count = self.db.upsert_financial_statements(accepted)

        # Audit logging
        status = "SUCCESS" if len(rejected) == 0 else ("PARTIAL" if len(accepted) > 0 else "FAILED")
        sym = raw_statements[0].get("symbol", "MULTI") if len(raw_statements) == 1 else "MULTI"
        self.db.record_audit_log(
            source=source,
            endpoint="financial_statements",
            symbol=sym,
            date_range_start=None,
            date_range_end=None,
            records_retrieved=len(raw_statements),
            records_accepted=len(accepted),
            records_rejected=len(rejected),
            validation_summary=summary,
            raw_payload_path="",
            status=status,
            created_at=retrieval_ts
        )

        return {
            "total_input": len(raw_statements),
            "accepted_count": len(accepted),
            "rejected_count": len(rejected),
            "inserted_or_updated": inserted_count,
            "rejections": rejected
        }

    def ingest_statements_from_file(self, file_path: str) -> Dict[str, Any]:
        """Loads and ingests financial statements from a JSON file."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        statements = data if isinstance(data, list) else data.get("statements", [])
        return self.ingest_financial_statements(statements, source=f"file:{os.path.basename(file_path)}")

    def compute_and_store_daily_factors(
        self,
        symbols: List[str],
        trading_dates: List[str],
        reporting_basis: str = "CONSOLIDATED"
    ) -> Dict[str, Any]:
        """
        Computes and stores daily fundamental factors for specified symbols and trading dates.
        On each date, calculates individual factors, then applies sector-relative ranking
        and universe valuation deciles before persisting.
        """
        total_computed = 0
        factors_to_persist: List[Dict[str, Any]] = []

        for t_date in trading_dates:
            date_factors: List[Dict[str, Any]] = []
            for sym in symbols:
                try:
                    f = self.engine.calculate_fundamental_factors(
                        symbol=sym,
                        trading_date=t_date,
                        db=self.db,
                        reporting_basis=reporting_basis
                    )
                    date_factors.append(f)
                except Exception as e:
                    # e.g., missing price on that date or invalid state
                    continue

            # Apply cross-sectional sector-relative and decile metrics
            if date_factors:
                enriched = self.engine.compute_sector_relative_factors(date_factors)
                factors_to_persist.extend(enriched)

        if factors_to_persist:
            total_computed = self.db.upsert_fundamental_factors_daily(factors_to_persist)

        return {
            "total_dates": len(trading_dates),
            "total_symbols": len(symbols),
            "total_factors_persisted": total_computed
        }

    def update_index_valuations(
        self,
        valuation_records: List[Dict[str, Any]]
    ) -> int:
        """
        Updates valuation columns (pe_ratio, pb_ratio, div_yield) for index_daily records.
        """
        updated_count = 0
        for rec in valuation_records:
            idx_name = rec.get("index_name")
            t_date = rec.get("trading_date")
            pe = rec.get("pe_ratio")
            pb = rec.get("pb_ratio")
            dy = rec.get("div_yield")
            if idx_name and t_date:
                rc = self.db.update_index_valuation(
                    index_name=idx_name,
                    trading_date=t_date,
                    pe_ratio=pe,
                    pb_ratio=pb,
                    div_yield=dy
                )
                updated_count += rc
        return updated_count
