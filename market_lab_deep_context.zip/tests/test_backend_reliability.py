"""
Unit and Integration Tests for Backend Reliability, Optional Dependencies & Daemon Lifecycle.
Workstream 4 / Audit Ticket: Finding 4, MIL-P0-008, MIL-BE-001, MIL-BE-003.

Verifies:
1. Module imports are resilient when optional dependencies like yfinance are unavailable.
2. Daemon _execute_eod_pipeline returns structured dict telemetry.
3. Settlement completion check uses dynamic securities_master count instead of hardcoded 150.
4. Failed settlement pipeline runs do not advance last_eod_date.
"""

import pytest
import asyncio
from unittest.mock import patch, MagicMock
from datetime import datetime, timezone

from src.storage.database import DatabaseManager
from src.tasks.daemon import AutonomousPlatformDaemon
import src.client.macro_client as macro_client_module
import src.pipeline.universe_ingestion as universe_ingestion_module


@pytest.fixture
def daemon_test_db(tmp_path):
    db_file = str(tmp_path / "test_daemon.db")
    db = DatabaseManager(db_file)
    with db.get_connection() as conn:
        conn.execute("""
            INSERT OR REPLACE INTO securities_master (symbol, company_name, isin, industry, sector, macro_sector, updated_at, is_active)
            VALUES ('TCS', 'Tata Consultancy Services', 'INE467B01029', 'IT', 'Tech', 'IT', '2026-11-06T00:00:00Z', 1);
        """)
        conn.commit()
    return db_file


def test_optional_dependency_isolation():
    """Ensure modules gracefully handle absence of yfinance."""
    with patch.object(macro_client_module, "yf", None):
        client = macro_client_module.MacroClient()
        data = client.get_macro_telemetry(force_refresh=True)
        assert "indicators" in data
        assert len(data["indicators"]) >= 3

    with patch.object(universe_ingestion_module, "yf", None):
        mgr = universe_ingestion_module.UniverseIngestionManager()
        sym, candles = mgr._fetch_symbol_candles("TCS")
        assert sym == "TCS"
        assert candles == []
        bench = mgr._fetch_benchmark_candles()
        assert bench == []


def test_daemon_eod_pipeline_structured_result(daemon_test_db):
    """Daemon _execute_eod_pipeline must return a structured dictionary."""
    daemon = AutonomousPlatformDaemon(db_path=daemon_test_db)
    
    with patch("src.pipeline.universe_ingestion.UniverseIngestionManager.execute_universe_ingestion") as mock_ingest:
        mock_ingest.return_value = {
            "status": "SUCCESS",
            "settled_date": "2026-11-06",
            "symbols_updated": 1,
            "records_ingested": 1,
            "factors_computed": 1,
            "duration_seconds": 0.5,
            "message": "Success"
        }
        res = daemon._execute_eod_pipeline("2026-11-06")
        assert isinstance(res, dict)
        assert res["status"] == "SUCCESS"
        assert res["target_date"] == "2026-11-06"
        assert res["factors_written"] == 1
        assert res["error"] is None


@pytest.mark.asyncio
async def test_daemon_failed_settlement_does_not_advance_date(daemon_test_db):
    """If EOD settlement fails, last_eod_date must NOT advance, allowing retry."""
    daemon = AutonomousPlatformDaemon(db_path=daemon_test_db)
    daemon.last_eod_date = None

    # Mock time to after 16:15 IST on a trading session
    ist_time = datetime(2026, 11, 6, 17, 0, 0)
    with patch.object(daemon, "_get_ist_now", return_value=ist_time), \
         patch("src.tasks.daemon.is_trading_session", return_value=True), \
         patch.object(daemon, "_execute_eod_pipeline", return_value={"status": "FAILED", "factors_written": 0}):
        
        await daemon.check_and_run_eod_settlement()
        # Must still be None because the pipeline failed!
        assert daemon.last_eod_date is None


@pytest.mark.asyncio
async def test_daemon_successful_settlement_advances_date(daemon_test_db):
    """If EOD settlement succeeds, last_eod_date advances."""
    daemon = AutonomousPlatformDaemon(db_path=daemon_test_db)
    daemon.last_eod_date = None

    ist_time = datetime(2026, 11, 6, 17, 0, 0)
    with patch.object(daemon, "_get_ist_now", return_value=ist_time), \
         patch("src.tasks.daemon.is_trading_session", return_value=True), \
         patch.object(daemon, "_execute_eod_pipeline", return_value={"status": "SUCCESS", "factors_written": 181}):
        
        await daemon.check_and_run_eod_settlement()
        assert daemon.last_eod_date == "2026-11-06"
