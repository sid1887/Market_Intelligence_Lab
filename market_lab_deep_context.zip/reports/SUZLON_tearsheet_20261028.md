# Company Research Tearsheet — SUZLON (Suzlon Energy Ltd)
**As-of Trading Session:** `2026-10-28` | **Generated:** `2026-11-05 12:03:36 UTC`  
**ISIN:** `INE040H01021` | **Industry:** `Heavy Electrical Equipment` | **Sector:** `Renewable Energy`  
**System Status:** Local-First SQLite Research Lab | **Execution Capabilities:** Permanently Disabled  

---

## 1. Executive Summary & Verified Empirical Facts

| Metric | Observed Value | Verification Status / Source Reference |
| :--- | :---: | :--- |
| **Closing Price (NSE)** | **₹36.85** | Primary CM-UDiFF Common Bhavcopy settlement |
| **Day's OHLC Range** | ₹36.64 – ₹37.07 | Open: ₹36.87 |
| **Day's Traded Volume** | 23,248,428 shares | Exchange turnover settlement |
| **Delivery Quantity** | *Unavailable in CM-UDiFF (Stored as NULL)* | Strict null preservation rule |
| **52-Week Range** | ₹31.39 – ₹37.93 | Trailing 245-session extreme closes |
| **52-Week Position** | **`83.5%`** | Position between 52w low (0%) and 52w high (100%) |

### 1.1 Verified Corporate Disclosures & Financial Results Metadata

| Disclosure ID | Effective Session | Category | Audit Status | Key Operational / Financial Fact | Direct Document URL |
| :--- | :---: | :---: | :---: | :--- | :--- |
| `SUZLON_DISC_20261014_ORDER` | `2026-10-14` | `GENERAL_ANNOUNCEMENT` | `UNAUDITED` | Secured 300 MW wind turbine supply and EPC installation order for... (**`VERIFIED`**) | [Official Document PDF](https://nsearchives.nseindia.com/corporate/SUZLON_14102026_Order_Win_300MW.pdf) |
| `SUZLON_DISC_20261024_Q2` | `2026-10-26` | `EARNINGS` | `AUDITED` | Q2 FY27 Consolidated Net Profit ₹360 Cr (+80% YoY), Revenue ₹2,51... (**`VERIFIED`**) | [Official Document PDF](https://nsearchives.nseindia.com/corporate/SUZLON_24102026_Q2_Results.pdf) |

> [!IMPORTANT]
> **Financial Field Integrity**: Operating financial figures reflect official board-approved disclosures. Latest filings confirm AUDITED status without metric contamination.

## 2. Deterministic Quantitative Analytics

### 2.1 Multi-Horizon Trailing Returns (Split/Bonus Adjusted)

| Horizon | Trading Days | Stock Return | Benchmark (Nifty 50 PRI) | Excess Return vs Benchmark |
| :---: | :---: | :---: | :---: | :---: |
| **1-Day (1D)** | 1 | `-2.15%` | `N/A` | **`N/A`** |
| **1-Month (1M)** | 21 | `+4.24%` | `N/A` | **`N/A`** |
| **3-Month (3M)** | 63 | `+13.42%` | `N/A` | **`N/A`** |
| **6-Month (6M)** | 126 | `+6.04%` | `N/A` | **`N/A`** |
| **1-Year (1Y)** | 245 | `+14.83%` | `N/A` | **`N/A`** |

> [!NOTE]
> **Return Horizon Methodology**: Trailing returns use fixed trading-session windows (1D = 1 trading session, 1M = 21 trading sessions, 3M = 63 trading sessions, 6M = 126 trading sessions, 1Y = 245 trading sessions), ensuring exact reproducibility across holidays and suspensions.


### 2.2 Moving Averages, Volatility & Risk Metrics

| Quantitative Metric | Value | Reference / Formula |
| :--- | :---: | :--- |
| **20-Day SMA** | ₹36.70 | Distance: **`+0.40%`** |
| **50-Day SMA** | ₹34.97 | Distance: **`+5.38%`** |
| **200-Day SMA** | ₹34.82 | Distance: **`+5.83%`** |
| **20-Day Annualized Volatility** | `8.77%` | Annualized standard deviation ($\sigma \times \sqrt{252}$) |
| **60-Day Rolling Beta (Nifty 50)** | **`N/A`** | OLS slope $\beta = \mathrm{Cov}(R_s, R_b) / \mathrm{Var}(R_b)$ |
| **20-Day Volume Ratio (VR 20)** | `1.25x` | Today Volume / 20-Day ADV (VR >= 2.5x threshold) |
| **50-Day Volume Z-Score ($Z_V$)** | `+1.00σ` | Normalized volume anomaly ($Z \ge 2.5\sigma$ threshold) |


## 3. Sector & Peer Relative Strength (Renewable Energy Peers)

| Peer Symbol | Latest Close | 1-Month Return | 3-Month Return | Excess vs SUZLON (1M) | Excess vs SUZLON (3M) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **SUZLON (Target)** | **₹36.85** | **`+4.24%`** | **`+13.42%`** | *Base* | *Base* |
| **TCS** | ₹2,460.00 | `+17.87%` | `+7.16%` | `+13.63%` | `-6.26%` |
| **HCLTECH** | ₹1,400.50 | `+12.62%` | `+8.07%` | `+8.37%` | `-5.35%` |
| **TECHM** | ₹1,776.60 | `+15.14%` | `+12.80%` | `+10.90%` | `-0.62%` |


## 4. Econometric Event Studies & Disclosures Audit

| Event ID / Disclosure | Event Session $t=0$ | Estimation Window | Abnormal Return $AR_0$ | $CAR[-1, +1]$ | $t$-stat ($p$-value) | Study Status & Guardrails |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| `SUZLON_DISC_20261024_Q2` | `2026-10-26` | `[-252, -21]` | `N/A` | `N/A` | `N/A` | ⏳ **`AWAITING_POST_EVENT_DATA`** |

### 4.1 Epistemic Guardrails & Provenance Warnings

1. **`SUZLON_DISC_20261014_ORDER` (Award of 300 MW Wind Energy Project Order from leading PSU)**: Verified official exchange filing under SEBI LODR regulations. Co-occurring returns reflect verified disclosures.
2. **`SUZLON_DISC_20261024_Q2` (Financial Results for the Quarter and Half Year ended September 30, 2026)**: Verified official exchange filing under SEBI LODR regulations. Co-occurring returns reflect verified disclosures.


## 5. Corporate Action Ledger & Downstream Protection

| Action Type | Ex-Date | Record Date | Purpose & Rate | Adjustment Factor | Historical Return Impact |
| :---: | :---: | :---: | :--- | :---: | :--- |
| *No Historical Actions* | N/A | N/A | No corporate actions recorded in 24-month horizon | 1.0000 | Unadjusted parity |

> [!NOTE]
> **Corporate Action Governance**: All historical corporate actions are fully incorporated via Mode 2 backward-proportional adjustment factors. No unexercised future actions are credited.

## 6. Explanatory Hypotheses & Scenario Projections

1. **Trend & Momentum Hypothesis**: SUZLON is currently positioned at `83.5%` of its 52-week range, trading `+0.40%` relative to its 20-day SMA and `+5.83%` relative to its 200-day SMA. This structural positioning indicates an ongoing intermediate consolidation phase following broad Renewable Energy sector movements.
2. **Downside Risk Scenario**: In the event that broader macroeconomic headwinds or sector deceleration emerge, key downside support aligns with the designated stop loss level of ₹33.00 (52-week trough at ₹31.39).
3. **Upside Rebound Scenario**: Conversely, sustained operational performance and sector re-rating position the instrument toward target price objective of ₹45.00, with intermediate resistance aligning with 50-day SMA (₹34.97) and 200-day SMA (₹34.82).

> [!CAUTION]
> **Epistemic Limitation**: All hypotheses and scenarios are probabilistic qualitative frameworks generated for quantitative research. They do not constitute financial advice, trade recommendations, or causal certainty. Live order placement is Permanently Disabled.
