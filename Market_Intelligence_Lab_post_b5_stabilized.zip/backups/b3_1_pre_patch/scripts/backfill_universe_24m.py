import time
import datetime
import sys
from src.storage.database import DatabaseManager
from src.client.backfill_manager import BackfillManager
from src.client.nse_mcp_client import NseMcpClient

def main():
    print("=== Milestone B3.1: 24-Month Universe Backfill ===")
    t0 = time.time()
    db = DatabaseManager("data/market_lab.db")
    mcp_client = NseMcpClient()
    bm = BackfillManager(db, mcp_client=mcp_client, min_required_records=480)

    with db.get_connection() as conn:
        c = conn.cursor()
        c.execute("SELECT DISTINCT symbol FROM ohlcv_daily WHERE series = 'EQ' ORDER BY symbol")
        all_symbols = [r[0] for r in c.fetchall()]

    to_process = bm.get_symbols_needing_backfill(all_symbols)
    print(f"Total symbols in universe: {len(all_symbols)}")
    print(f"Symbols needing backfill to >= 480 records: {len(to_process)}")

    if not to_process:
        print("All symbols already meet or exceed 480 records.")
        return

    mcp_client.initialize()
    completed = []
    failed = []

    for idx, sym in enumerate(to_process, 1):
        st = time.time()
        success = False
        last_res = None

        # Retry up to 3 times per symbol
        for attempt in range(1, 4):
            try:
                res = bm.backfill_symbol(sym, total_months=24, end_date="2026-10-23")
                last_res = res
                if res.get("status") == "SUCCESS" and res.get("records_upserted", 0) > 0:
                    success = True
                    break
                else:
                    print(f"  Attempt {attempt} for {sym} returned: {res.get('error', '0 upserted')}. Retrying...")
                    time.sleep(1.0)
                    mcp_client.session_id = None  # Force re-init on retry
            except Exception as e:
                print(f"  Attempt {attempt} for {sym} raised exception: {e}. Retrying...")
                time.sleep(1.0)
                mcp_client.session_id = None

        dur = time.time() - st
        if success:
            completed.append(sym)
            upserted = last_res.get("records_upserted", 0)
            drange = last_res.get("date_range", "")
            print(f"[{idx:2d}/{len(to_process)}] {sym:12} -> OK ({upserted} records, {drange}) in {dur:.2f}s", flush=True)
        else:
            failed.append((sym, last_res))
            print(f"[{idx:2d}/{len(to_process)}] {sym:12} -> FAILED after 3 attempts in {dur:.2f}s", flush=True)

        time.sleep(0.2)

    total_time = time.time() - t0
    print(f"\n--- Backfill Finished in {total_time:.2f}s ({total_time/60:.2f} min) ---")
    print(f"Successfully backfilled: {len(completed)} / {len(to_process)}")
    if failed:
        print(f"Failed symbols ({len(failed)}): {[f[0] for f in failed]}")

    # Verify final counts in database
    with db.get_connection() as conn:
        c = conn.cursor()
        c.execute("""
            SELECT 
                COUNT(DISTINCT symbol) as total_symbols,
                COUNT(*) as total_rows,
                MIN(cnt) as min_count,
                MAX(cnt) as max_count
            FROM (
                SELECT symbol, COUNT(*) as cnt 
                FROM ohlcv_daily 
                WHERE series = 'EQ' 
                GROUP BY symbol
            )
        """)
        summary = c.fetchone()
        print("\n--- Final Database Status for ohlcv_daily ---")
        print(f"Distinct symbols: {summary[0]}")
        print(f"Total OHLCV rows (EQ): {summary[1]}")
        print(f"Min records per stock: {summary[2]}")
        print(f"Max records per stock: {summary[3]}")

        c.execute("""
            SELECT symbol, COUNT(*) 
            FROM ohlcv_daily 
            WHERE series = 'EQ' 
            GROUP BY symbol 
            HAVING COUNT(*) < 480
        """)
        sub_480 = c.fetchall()
        if sub_480:
            print(f"WARNING: Symbols with < 480 records: {sub_480}")
        else:
            print("SUCCESS: 100% of constituents have >= 480 trading sessions!")

if __name__ == "__main__":
    main()
