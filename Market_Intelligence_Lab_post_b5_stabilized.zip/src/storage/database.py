import sqlite3
import os
import json
from typing import List, Dict, Any, Optional

class DatabaseManager:
    """Manages SQLite database connections, additive schema migrations, and transactional persistence."""

    def __init__(self, db_path: str = "data/market_lab.db"):
        self.db_path = db_path
        self._mem_conn: Optional[sqlite3.Connection] = None
        if self.db_path == ":memory:":
            self._mem_conn = sqlite3.connect(":memory:")
            self._mem_conn.row_factory = sqlite3.Row
        else:
            os.makedirs(os.path.dirname(os.path.abspath(self.db_path)), exist_ok=True)
        self.init_schema()

    def get_connection(self) -> sqlite3.Connection:
        if self._mem_conn is not None:
            return self._mem_conn
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        return conn

    def init_schema(self) -> None:
        """Applies base Phase 1 schema, Phase 2 migration, and safe column alterations."""
        schema_dir = os.path.dirname(__file__)
        schema_v1_path = os.path.join(schema_dir, "schema.sql")
        schema_v2_path = os.path.join(schema_dir, "schema_v2.sql")
        schema_v3_path = os.path.join(schema_dir, "schema_v3.sql")

        with self.get_connection() as conn:
            # 1. Base Phase 1 Schema
            if os.path.exists(schema_v1_path):
                with open(schema_v1_path, "r", encoding="utf-8") as f:
                    conn.executescript(f.read())

            # 2. Safe additive column alterations on ohlcv_daily
            cursor = conn.execute("PRAGMA table_info(ohlcv_daily);")
            existing_cols = {row["name"] for row in cursor.fetchall()}
            if "trades_count" not in existing_cols:
                conn.execute("ALTER TABLE ohlcv_daily ADD COLUMN trades_count INTEGER DEFAULT NULL;")
            if "data_status" not in existing_cols:
                conn.execute("ALTER TABLE ohlcv_daily ADD COLUMN data_status TEXT NOT NULL DEFAULT 'final_settled';")

            # 3. Phase 2 Schema Extension
            if os.path.exists(schema_v2_path):
                with open(schema_v2_path, "r", encoding="utf-8") as f:
                    conn.executescript(f.read())

            # 3b. Phase 3 / Milestone B5 Schema Extension
            if os.path.exists(schema_v3_path):
                with open(schema_v3_path, "r", encoding="utf-8") as f:
                    conn.executescript(f.read())

            # 4. Safe additive column alterations on corporate_disclosures
            cursor = conn.execute("PRAGMA table_info(corporate_disclosures);")
            disc_cols = {row["name"] for row in cursor.fetchall()}
            if disc_cols:
                if "verification_status" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'PENDING_VERIFICATION';")
                if "audit_status" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN audit_status TEXT DEFAULT NULL;")
                if "dividend_declared" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN dividend_declared REAL DEFAULT NULL;")
                if "operating_margin_pct" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN operating_margin_pct REAL DEFAULT NULL;")
                if "revenue_inr_crore" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_inr_crore REAL DEFAULT NULL;")
                if "revenue_growth_yoy_cc" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_growth_yoy_cc REAL DEFAULT NULL;")
                if "revenue_growth_qoq_cc" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_growth_qoq_cc REAL DEFAULT NULL;")
                if "revenue_growth_yoy_reported" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_growth_yoy_reported REAL DEFAULT NULL;")
                if "source_timestamp_basis" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN source_timestamp_basis TEXT DEFAULT NULL;")

            # 5. Schema safeguard: Ensure corporate_disclosures defaults to 'PENDING_VERIFICATION' at SQLite level
            cursor = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='corporate_disclosures';")
            tbl_sql_row = cursor.fetchone()
            if tbl_sql_row and "DEFAULT 'VERIFIED'" in tbl_sql_row[0]:
                self._migrate_corporate_disclosures_default(conn)

            # 6. Safe additive column alterations on corporate_actions
            cursor = conn.execute("PRAGMA table_info(corporate_actions);")
            ca_cols = {row["name"] for row in cursor.fetchall()}
            if ca_cols:
                if "announcement_date" not in ca_cols:
                    conn.execute("ALTER TABLE corporate_actions ADD COLUMN announcement_date TEXT DEFAULT NULL;")
                if "effective_date" not in ca_cols:
                    conn.execute("ALTER TABLE corporate_actions ADD COLUMN effective_date TEXT DEFAULT NULL;")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_ca_action_type ON corporate_actions(action_type);")

            # 7. Safe primary key migration on corporate_actions to include purpose
            self._migrate_corporate_actions_pk(conn)

    def _migrate_corporate_actions_pk(self, conn: sqlite3.Connection) -> None:
        """Migrates corporate_actions table so PRIMARY KEY includes purpose (symbol, action_type, ex_date, purpose)."""
        cursor = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='corporate_actions';")
        tbl_sql_row = cursor.fetchone()
        if tbl_sql_row and "PRIMARY KEY" in tbl_sql_row[0]:
            pk_part = tbl_sql_row[0].split("PRIMARY KEY")[1]
            if "purpose" not in pk_part:
                conn.execute("PRAGMA foreign_keys = OFF;")
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS corporate_actions_migrated (
                        symbol TEXT NOT NULL,
                        action_type TEXT NOT NULL,
                        ex_date TEXT NOT NULL,
                        record_date TEXT DEFAULT NULL,
                        announcement_date TEXT DEFAULT NULL,
                        effective_date TEXT DEFAULT NULL,
                        purpose TEXT NOT NULL,
                        adjustment_factor REAL DEFAULT 1.0,
                        source TEXT NOT NULL,
                        retrieval_timestamp TEXT NOT NULL,
                        PRIMARY KEY (symbol, action_type, ex_date, purpose)
                    );
                """)
                conn.execute("""
                    INSERT OR IGNORE INTO corporate_actions_migrated (
                        symbol, action_type, ex_date, record_date, announcement_date,
                        effective_date, purpose, adjustment_factor, source, retrieval_timestamp
                    )
                    SELECT 
                        symbol, action_type, ex_date, record_date, announcement_date,
                        effective_date, purpose, adjustment_factor, source, retrieval_timestamp
                    FROM corporate_actions;
                """)
                conn.execute("DROP TABLE corporate_actions;")
                conn.execute("ALTER TABLE corporate_actions_migrated RENAME TO corporate_actions;")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_ca_symbol_exdate ON corporate_actions(symbol, ex_date);")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_ca_action_type ON corporate_actions(action_type);")
                conn.execute("PRAGMA foreign_keys = ON;")

    def _migrate_corporate_disclosures_default(self, conn: sqlite3.Connection) -> None:
        """Migrates corporate_disclosures table so verification_status defaults to PENDING_VERIFICATION."""
        conn.execute("PRAGMA foreign_keys = OFF;")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS corporate_disclosures_migrated (
                disclosure_id TEXT PRIMARY KEY,
                symbol TEXT NOT NULL,
                broadcast_timestamp TEXT NOT NULL,
                effective_session_date TEXT NOT NULL,
                category TEXT NOT NULL,
                subject TEXT NOT NULL,
                details_summary TEXT,
                source_url TEXT,
                retrieval_timestamp TEXT NOT NULL,
                verification_status TEXT NOT NULL DEFAULT 'PENDING_VERIFICATION',
                audit_status TEXT DEFAULT NULL,
                dividend_declared REAL DEFAULT NULL,
                operating_margin_pct REAL DEFAULT NULL,
                revenue_inr_crore REAL DEFAULT NULL,
                revenue_growth_yoy_cc REAL DEFAULT NULL,
                revenue_growth_qoq_cc REAL DEFAULT NULL,
                revenue_growth_yoy_reported REAL DEFAULT NULL,
                source_timestamp_basis TEXT DEFAULT NULL
            );
        """)
        conn.execute("""
            INSERT INTO corporate_disclosures_migrated (
                disclosure_id, symbol, broadcast_timestamp, effective_session_date,
                category, subject, details_summary, source_url, retrieval_timestamp,
                verification_status, audit_status, dividend_declared, operating_margin_pct,
                revenue_inr_crore, revenue_growth_yoy_cc, revenue_growth_qoq_cc,
                revenue_growth_yoy_reported, source_timestamp_basis
            )
            SELECT 
                disclosure_id, symbol, broadcast_timestamp, effective_session_date,
                category, subject, details_summary, source_url, retrieval_timestamp,
                verification_status, audit_status, dividend_declared, operating_margin_pct,
                revenue_inr_crore, revenue_growth_yoy_cc, revenue_growth_qoq_cc,
                revenue_growth_yoy_reported, source_timestamp_basis
            FROM corporate_disclosures;
        """)
        conn.execute("DROP TABLE corporate_disclosures;")
        conn.execute("ALTER TABLE corporate_disclosures_migrated RENAME TO corporate_disclosures;")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_disc_symbol_session ON corporate_disclosures(symbol, effective_session_date);")
        conn.execute("PRAGMA foreign_keys = ON;")

    def upsert_ohlcv_records(self, records: List[Dict[str, Any]]) -> int:
        """
        Upserts validated OHLCV records.
        Unavailable fields (such as delivery_qty or trades_count) are stored as NULL.
        """
        if not records:
            return 0

        # Normalize optional fields so sqlite3 binding parameters are never missing
        normalized = []
        for r in records:
            item = dict(r)
            if "ltp" not in item:
                item["ltp"] = None
            if "prev_close" not in item:
                item["prev_close"] = None
            if "turnover" not in item:
                item["turnover"] = None
            if "delivery_qty" not in item:
                item["delivery_qty"] = None
            if "trades_count" not in item:
                item["trades_count"] = None
            if "data_status" not in item:
                item["data_status"] = "final_settled"
            normalized.append(item)

        sql = """
        INSERT INTO ohlcv_daily (
            symbol, trading_date, series, open, high, low, close,
            ltp, prev_close, volume, turnover, delivery_qty,
            source, retrieval_timestamp, trades_count, data_status
        ) VALUES (
            :symbol, :trading_date, :series, :open, :high, :low, :close,
            :ltp, :prev_close, :volume, :turnover, :delivery_qty,
            :source, :retrieval_timestamp, :trades_count, :data_status
        )
        ON CONFLICT(symbol, trading_date, series) DO UPDATE SET
            open = excluded.open,
            high = excluded.high,
            low = excluded.low,
            close = excluded.close,
            ltp = excluded.ltp,
            prev_close = excluded.prev_close,
            volume = excluded.volume,
            turnover = excluded.turnover,
            delivery_qty = excluded.delivery_qty,
            source = excluded.source,
            retrieval_timestamp = excluded.retrieval_timestamp,
            trades_count = excluded.trades_count,
            data_status = excluded.data_status
        WHERE ohlcv_daily.data_status != 'final_settled' OR excluded.data_status = 'final_settled';
        """

        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def upsert_corporate_actions(self, actions: List[Dict[str, Any]]) -> int:
        if not actions:
            return 0

        normalized = []
        for a in actions:
            item = dict(a)
            if "record_date" not in item:
                item["record_date"] = None
            if "announcement_date" not in item:
                item["announcement_date"] = None
            if "effective_date" not in item:
                item["effective_date"] = None
            if "adjustment_factor" not in item or item["adjustment_factor"] is None:
                item["adjustment_factor"] = 1.0
            normalized.append(item)

        sql = """
        INSERT INTO corporate_actions (
            symbol, action_type, ex_date, record_date, purpose,
            adjustment_factor, source, retrieval_timestamp,
            announcement_date, effective_date
        ) VALUES (
            :symbol, :action_type, :ex_date, :record_date, :purpose,
            :adjustment_factor, :source, :retrieval_timestamp,
            :announcement_date, :effective_date
        )
        ON CONFLICT(symbol, action_type, ex_date, purpose) DO UPDATE SET
            record_date = excluded.record_date,
            adjustment_factor = excluded.adjustment_factor,
            source = excluded.source,
            retrieval_timestamp = excluded.retrieval_timestamp,
            announcement_date = excluded.announcement_date,
            effective_date = excluded.effective_date;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def record_audit_log(
        self,
        source: str,
        endpoint: str,
        symbol: str,
        date_range_start: Optional[str],
        date_range_end: Optional[str],
        records_retrieved: int,
        records_accepted: int,
        records_rejected: int,
        validation_summary: Dict[str, Any],
        raw_payload_path: str,
        status: str,
        created_at: str
    ) -> int:
        sql = """
        INSERT INTO ingestion_audit_log (
            source, endpoint, symbol, date_range_start, date_range_end,
            records_retrieved, records_accepted, records_rejected,
            validation_summary, raw_payload_path, status, created_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        );
        """
        with self.get_connection() as conn:
            cursor = conn.execute(sql, (
                source, endpoint, symbol, date_range_start, date_range_end,
                records_retrieved, records_accepted, records_rejected,
                json.dumps(validation_summary), raw_payload_path, status, created_at
            ))
            return cursor.lastrowid

    def get_stock_history(
        self,
        symbol: str,
        series: str = "EQ",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM ohlcv_daily WHERE symbol = ? AND series = ?"
        params: List[Any] = [symbol, series]

        if start_date:
            query += " AND trading_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND trading_date <= ?"
            params.append(end_date)

        query += " ORDER BY trading_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_corporate_actions(
        self,
        symbol: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        action_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM corporate_actions WHERE 1=1"
        params: List[Any] = []

        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        if start_date:
            query += " AND ex_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND ex_date <= ?"
            params.append(end_date)
        if action_type:
            query += " AND action_type = ?"
            params.append(action_type)

        query += " ORDER BY ex_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    # -------------------------------------------------------------
    # Phase 2 Extension Methods
    # -------------------------------------------------------------

    def upsert_securities_master(self, securities: List[Dict[str, Any]]) -> int:
        if not securities:
            return 0
        sql = """
        INSERT INTO securities_master (
            symbol, company_name, isin, industry, sector, macro_sector, listing_date, is_active, updated_at
        ) VALUES (
            :symbol, :company_name, :isin, :industry, :sector, :macro_sector, :listing_date, :is_active, :updated_at
        )
        ON CONFLICT(symbol) DO UPDATE SET
            company_name = excluded.company_name,
            isin = excluded.isin,
            industry = excluded.industry,
            sector = excluded.sector,
            macro_sector = excluded.macro_sector,
            listing_date = excluded.listing_date,
            is_active = excluded.is_active,
            updated_at = excluded.updated_at;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, securities)
            return cursor.rowcount

    def get_securities_master(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        query = "SELECT * FROM securities_master"
        params: List[Any] = []
        if symbol:
            query += " WHERE symbol = ?"
            params.append(symbol)
        query += " ORDER BY symbol ASC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def upsert_index_membership_history(self, records: List[Dict[str, Any]]) -> int:
        if not records:
            return 0
        sql = """
        INSERT INTO index_membership_history (
            symbol, index_name, valid_from, valid_to, is_verified_historical, source, retrieved_at
        ) VALUES (
            :symbol, :index_name, :valid_from, :valid_to, :is_verified_historical, :source, :retrieved_at
        )
        ON CONFLICT(symbol, index_name, valid_from) DO UPDATE SET
            valid_to = excluded.valid_to,
            is_verified_historical = excluded.is_verified_historical,
            source = excluded.source,
            retrieved_at = excluded.retrieved_at;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, records)
            return cursor.rowcount

    def get_index_constituents(self, index_name: str, as_of_date: str) -> Dict[str, Any]:
        """
        Retrieves point-in-time index constituents as of a given date.
        Detects whether any returned constituent uses unverified proxy membership.
        """
        sql = """
        SELECT symbol, is_verified_historical, source
        FROM index_membership_history
        WHERE index_name = ?
          AND valid_from <= ?
          AND (valid_to IS NULL OR valid_to > ?)
        ORDER BY symbol ASC;
        """
        with self.get_connection() as conn:
            cursor = conn.execute(sql, (index_name, as_of_date, as_of_date))
            rows = [dict(r) for r in cursor.fetchall()]

        if not rows:
            return {
                "index_name": index_name,
                "as_of_date": as_of_date,
                "count": 0,
                "constituents": [],
                "is_survivorship_bias_free": False,
                "membership_basis": "empty_or_unindexed",
                "warning": f"No constituents indexed for {index_name} as of {as_of_date}."
            }

        symbols = [r["symbol"] for r in rows]
        all_verified = all(r["is_verified_historical"] == 1 for r in rows)
        membership_basis = "survivorship_bias_free" if all_verified else "current_proxy_unadjusted"
        warning = None
        if not all_verified:
            warning = (
                f"Historical index membership for {index_name} on {as_of_date} contains proxy observations "
                "(membership_basis: current_proxy_unadjusted). Results may exhibit survivorship bias."
            )

        return {
            "index_name": index_name,
            "as_of_date": as_of_date,
            "count": len(symbols),
            "constituents": symbols,
            "is_survivorship_bias_free": all_verified,
            "membership_basis": membership_basis,
            "warning": warning
        }

    def upsert_index_daily(self, records: List[Dict[str, Any]]) -> int:
        """
        Upserts daily index series.
        For TRI records, open, high, and low are stored as NULL (None), never fabricated.
        """
        if not records:
            return 0

        normalized = []
        for r in records:
            item = dict(r)
            if "open" not in item:
                item["open"] = None
            if "high" not in item:
                item["high"] = None
            if "low" not in item:
                item["low"] = None
            if "volume" not in item:
                item["volume"] = None
            if "pe_ratio" not in item:
                item["pe_ratio"] = None
            if "pb_ratio" not in item:
                item["pb_ratio"] = None
            if "div_yield" not in item:
                item["div_yield"] = None
            normalized.append(item)

        sql = """
        INSERT INTO index_daily (
            index_name, trading_date, index_type, open, high, low, close,
            volume, pe_ratio, pb_ratio, div_yield, source, retrieval_timestamp
        ) VALUES (
            :index_name, :trading_date, :index_type, :open, :high, :low, :close,
            :volume, :pe_ratio, :pb_ratio, :div_yield, :source, :retrieval_timestamp
        )
        ON CONFLICT(index_name, trading_date, index_type) DO UPDATE SET
            open = excluded.open,
            high = excluded.high,
            low = excluded.low,
            close = excluded.close,
            volume = excluded.volume,
            pe_ratio = excluded.pe_ratio,
            pb_ratio = excluded.pb_ratio,
            div_yield = excluded.div_yield,
            source = excluded.source,
            retrieval_timestamp = excluded.retrieval_timestamp;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def get_index_history(
        self,
        index_name: str,
        index_type: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM index_daily WHERE index_name = ? AND index_type = ?"
        params: List[Any] = [index_name, index_type.upper()]

        if start_date:
            query += " AND trading_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND trading_date <= ?"
            params.append(end_date)

        query += " ORDER BY trading_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def upsert_quant_factors(self, factors: List[Dict[str, Any]]) -> int:
        """
        Upserts calculated daily quantitative factors.
        Rolling factors with incomplete warm-up windows are permitted as NULL.
        """
        if not factors:
            return 0
        sql = """
        INSERT INTO quant_factors_daily (
            symbol, trading_date, ret_1d, ret_5d, ret_20d, vol_20d_annualized,
            sma_20, sma_50, sma_200, beta_60d_nifty, volume_ratio_20d,
            volume_zscore_50d, volume_log_zscore_50d, is_volume_spike_ratio,
            is_volume_spike_zscore, distance_52w_high, distance_52w_low
        ) VALUES (
            :symbol, :trading_date, :ret_1d, :ret_5d, :ret_20d, :vol_20d_annualized,
            :sma_20, :sma_50, :sma_200, :beta_60d_nifty, :volume_ratio_20d,
            :volume_zscore_50d, :volume_log_zscore_50d, :is_volume_spike_ratio,
            :is_volume_spike_zscore, :distance_52w_high, :distance_52w_low
        )
        ON CONFLICT(symbol, trading_date) DO UPDATE SET
            ret_1d = excluded.ret_1d,
            ret_5d = excluded.ret_5d,
            ret_20d = excluded.ret_20d,
            vol_20d_annualized = excluded.vol_20d_annualized,
            sma_20 = excluded.sma_20,
            sma_50 = excluded.sma_50,
            sma_200 = excluded.sma_200,
            beta_60d_nifty = excluded.beta_60d_nifty,
            volume_ratio_20d = excluded.volume_ratio_20d,
            volume_zscore_50d = excluded.volume_zscore_50d,
            volume_log_zscore_50d = excluded.volume_log_zscore_50d,
            is_volume_spike_ratio = excluded.is_volume_spike_ratio,
            is_volume_spike_zscore = excluded.is_volume_spike_zscore,
            distance_52w_high = excluded.distance_52w_high,
            distance_52w_low = excluded.distance_52w_low;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, factors)
            return cursor.rowcount

    def get_quant_factors(
        self,
        symbol: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM quant_factors_daily WHERE symbol = ?"
        params: List[Any] = [symbol]

        if start_date:
            query += " AND trading_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND trading_date <= ?"
            params.append(end_date)

        query += " ORDER BY trading_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def upsert_corporate_disclosures(self, disclosures: List[Dict[str, Any]]) -> int:
        if not disclosures:
            return 0

        normalized = []
        for d in disclosures:
            item = dict(d)
            if "details_summary" not in item:
                item["details_summary"] = None
            if "source_url" not in item:
                item["source_url"] = None
            if "verification_status" not in item or not item["verification_status"]:
                item["verification_status"] = "PENDING_VERIFICATION"
            if "audit_status" not in item:
                item["audit_status"] = None
            if "dividend_declared" not in item:
                item["dividend_declared"] = None
            if "operating_margin_pct" not in item:
                item["operating_margin_pct"] = None
            if "revenue_inr_crore" not in item:
                item["revenue_inr_crore"] = None
            if "revenue_growth_yoy_cc" not in item:
                item["revenue_growth_yoy_cc"] = None
            if "revenue_growth_qoq_cc" not in item:
                item["revenue_growth_qoq_cc"] = None
            if "revenue_growth_yoy_reported" not in item:
                item["revenue_growth_yoy_reported"] = None
            if "source_timestamp_basis" not in item:
                item["source_timestamp_basis"] = None
            normalized.append(item)

        sql = """
        INSERT INTO corporate_disclosures (
            disclosure_id, symbol, broadcast_timestamp, effective_session_date,
            category, subject, details_summary, source_url, retrieval_timestamp,
            verification_status, audit_status, dividend_declared, operating_margin_pct,
            revenue_inr_crore, revenue_growth_yoy_cc, revenue_growth_qoq_cc,
            revenue_growth_yoy_reported, source_timestamp_basis
        ) VALUES (
            :disclosure_id, :symbol, :broadcast_timestamp, :effective_session_date,
            :category, :subject, :details_summary, :source_url, :retrieval_timestamp,
            :verification_status, :audit_status, :dividend_declared, :operating_margin_pct,
            :revenue_inr_crore, :revenue_growth_yoy_cc, :revenue_growth_qoq_cc,
            :revenue_growth_yoy_reported, :source_timestamp_basis
        )
        ON CONFLICT(disclosure_id) DO UPDATE SET
            symbol = excluded.symbol,
            broadcast_timestamp = excluded.broadcast_timestamp,
            effective_session_date = excluded.effective_session_date,
            category = excluded.category,
            subject = excluded.subject,
            details_summary = excluded.details_summary,
            source_url = excluded.source_url,
            retrieval_timestamp = excluded.retrieval_timestamp,
            verification_status = excluded.verification_status,
            audit_status = excluded.audit_status,
            dividend_declared = excluded.dividend_declared,
            operating_margin_pct = excluded.operating_margin_pct,
            revenue_inr_crore = excluded.revenue_inr_crore,
            revenue_growth_yoy_cc = excluded.revenue_growth_yoy_cc,
            revenue_growth_qoq_cc = excluded.revenue_growth_qoq_cc,
            revenue_growth_yoy_reported = excluded.revenue_growth_yoy_reported,
            source_timestamp_basis = excluded.source_timestamp_basis;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def get_corporate_disclosures(
        self,
        symbol: Optional[str] = None,
        verification_status: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM corporate_disclosures"
        clauses = []
        params = []
        if symbol:
            clauses.append("symbol = ?")
            params.append(symbol)
        if verification_status:
            clauses.append("verification_status = ?")
            params.append(verification_status)
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY effective_session_date ASC, broadcast_timestamp ASC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def record_event_study_result(self, result: Dict[str, Any]) -> int:
        sql = """
        INSERT INTO event_study_results (
            symbol, disclosure_id, event_date, estimation_window_start,
            estimation_window_end, model_alpha, model_beta, model_r2,
            ar_t0, car_minus1_plus1, car_0_plus2, t_stat, p_value,
            explanatory_hypothesis, calculated_at
        ) VALUES (
            :symbol, :disclosure_id, :event_date, :estimation_window_start,
            :estimation_window_end, :model_alpha, :model_beta, :model_r2,
            :ar_t0, :car_minus1_plus1, :car_0_plus2, :t_stat, :p_value,
            :explanatory_hypothesis, :calculated_at
        );
        """
        with self.get_connection() as conn:
            cursor = conn.execute(sql, result)
            return cursor.lastrowid

    def get_event_study_results(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        query = "SELECT * FROM event_study_results"
        params: List[Any] = []
        if symbol:
            query += " WHERE symbol = ?"
            params.append(symbol)
        query += " ORDER BY study_id DESC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    # -------------------------------------------------------------
    # Milestone B4: Company Financial Statements & Fundamental Factors
    # -------------------------------------------------------------

    def upsert_financial_statements(self, statements: List[Dict[str, Any]]) -> int:
        if not statements:
            return 0

        normalized = []
        for s in statements:
            item = dict(s)
            item.setdefault("fiscal_quarter", None)
            item.setdefault("publication_date", None)
            item.setdefault("broadcast_timestamp", None)
            item.setdefault("effective_session_date", None)
            item.setdefault("source_timestamp_basis", "EXACT_EXCHANGE_TIMESTAMP")
            item.setdefault("is_pit_eligible", 1)
            item.setdefault("statement_version", 1)
            item.setdefault("audit_status", "UNAUDITED")
            item.setdefault("currency", "INR")
            item.setdefault("unit", "CRORE")
            item.setdefault("revenue_operations", None)
            item.setdefault("other_income", None)
            item.setdefault("total_revenue", None)
            item.setdefault("operating_expenses", None)
            item.setdefault("ebitda", None)
            item.setdefault("ebit", None)
            item.setdefault("finance_costs", None)
            item.setdefault("depreciation_amortization", None)
            item.setdefault("profit_before_tax", None)
            item.setdefault("tax_expense", None)
            item.setdefault("net_profit", None)
            item.setdefault("basic_eps", None)
            item.setdefault("diluted_eps", None)
            item.setdefault("total_equity", None)
            item.setdefault("total_debt", None)
            item.setdefault("cash_and_equivalents", None)
            item.setdefault("total_assets", None)
            item.setdefault("shares_outstanding", None)
            item.setdefault("source_url", None)
            item.setdefault("verification_status", "PENDING_VERIFICATION")
            item.setdefault("is_restated", 0)
            item.setdefault("restatement_reason", None)
            normalized.append(item)

        sql = """
        INSERT INTO company_financial_statements (
            statement_id, symbol, period_type, period_nature, fiscal_year,
            fiscal_quarter, period_start_date, period_end_date, publication_date,
            broadcast_timestamp, effective_session_date, source_timestamp_basis,
            is_pit_eligible, reporting_basis, statement_version, audit_status,
            currency, unit, revenue_operations, other_income, total_revenue,
            operating_expenses, ebitda, ebit, finance_costs, depreciation_amortization,
            profit_before_tax, tax_expense, net_profit, basic_eps, diluted_eps,
            total_equity, total_debt, cash_and_equivalents, total_assets,
            shares_outstanding, source, source_url, retrieval_timestamp,
            verification_status, is_restated, restatement_reason
        ) VALUES (
            :statement_id, :symbol, :period_type, :period_nature, :fiscal_year,
            :fiscal_quarter, :period_start_date, :period_end_date, :publication_date,
            :broadcast_timestamp, :effective_session_date, :source_timestamp_basis,
            :is_pit_eligible, :reporting_basis, :statement_version, :audit_status,
            :currency, :unit, :revenue_operations, :other_income, :total_revenue,
            :operating_expenses, :ebitda, :ebit, :finance_costs, :depreciation_amortization,
            :profit_before_tax, :tax_expense, :net_profit, :basic_eps, :diluted_eps,
            :total_equity, :total_debt, :cash_and_equivalents, :total_assets,
            :shares_outstanding, :source, :source_url, :retrieval_timestamp,
            :verification_status, :is_restated, :restatement_reason
        )
        ON CONFLICT(symbol, period_end_date, period_type, period_nature, reporting_basis, statement_version) DO UPDATE SET
            statement_id = excluded.statement_id,
            fiscal_year = excluded.fiscal_year,
            fiscal_quarter = excluded.fiscal_quarter,
            period_start_date = excluded.period_start_date,
            publication_date = excluded.publication_date,
            broadcast_timestamp = excluded.broadcast_timestamp,
            effective_session_date = excluded.effective_session_date,
            source_timestamp_basis = excluded.source_timestamp_basis,
            is_pit_eligible = excluded.is_pit_eligible,
            audit_status = excluded.audit_status,
            currency = excluded.currency,
            unit = excluded.unit,
            revenue_operations = excluded.revenue_operations,
            other_income = excluded.other_income,
            total_revenue = excluded.total_revenue,
            operating_expenses = excluded.operating_expenses,
            ebitda = excluded.ebitda,
            ebit = excluded.ebit,
            finance_costs = excluded.finance_costs,
            depreciation_amortization = excluded.depreciation_amortization,
            profit_before_tax = excluded.profit_before_tax,
            tax_expense = excluded.tax_expense,
            net_profit = excluded.net_profit,
            basic_eps = excluded.basic_eps,
            diluted_eps = excluded.diluted_eps,
            total_equity = excluded.total_equity,
            total_debt = excluded.total_debt,
            cash_and_equivalents = excluded.cash_and_equivalents,
            total_assets = excluded.total_assets,
            shares_outstanding = excluded.shares_outstanding,
            source = excluded.source,
            source_url = excluded.source_url,
            retrieval_timestamp = excluded.retrieval_timestamp,
            verification_status = excluded.verification_status,
            is_restated = excluded.is_restated,
            restatement_reason = excluded.restatement_reason;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def get_financial_statements(
        self,
        symbol: Optional[str] = None,
        period_type: Optional[str] = None,
        reporting_basis: Optional[str] = None,
        period_nature: Optional[str] = None,
        is_pit_eligible: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM company_financial_statements WHERE 1=1"
        params: List[Any] = []
        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        if period_type:
            query += " AND period_type = ?"
            params.append(period_type)
        if reporting_basis:
            query += " AND reporting_basis = ?"
            params.append(reporting_basis)
        if period_nature:
            query += " AND period_nature = ?"
            params.append(period_nature)
        if is_pit_eligible is not None:
            query += " AND is_pit_eligible = ?"
            params.append(is_pit_eligible)
        query += " ORDER BY period_end_date DESC, statement_version DESC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_point_in_time_statements(
        self,
        symbol: str,
        as_of_date: str,
        reporting_basis: str = "CONSOLIDATED",
        period_nature: str = "DISCRETE_QUARTER",
        limit: int = 8
    ) -> List[Dict[str, Any]]:
        """
        Point-in-Time Query:
        Retrieves company financial statements published strictly on or before `as_of_date`
        (effective_session_date <= as_of_date), selecting the latest available statement_version
        for each distinct period_end_date.
        Prevents look-ahead bias and correctly handles restatements as of the evaluation date.
        """
        query = """
        WITH AvailableStatements AS (
            SELECT *,
                   ROW_NUMBER() OVER(
                       PARTITION BY symbol, period_end_date, period_type, period_nature, reporting_basis
                       ORDER BY statement_version DESC
                   ) as rn
            FROM company_financial_statements
            WHERE symbol = ?
              AND reporting_basis = ?
              AND period_nature = ?
              AND is_pit_eligible = 1
              AND (
                  (effective_session_date IS NOT NULL AND effective_session_date <= ?)
                  OR
                  (effective_session_date IS NULL AND publication_date IS NOT NULL AND publication_date <= ?)
              )
        )
        SELECT * FROM AvailableStatements
        WHERE rn = 1
        ORDER BY period_end_date DESC
        LIMIT ?;
        """
        with self.get_connection() as conn:
            cursor = conn.execute(query, (symbol, reporting_basis, period_nature, as_of_date, as_of_date, limit))
            return [dict(row) for row in cursor.fetchall()]

    def upsert_fundamental_factors_daily(self, factors: List[Dict[str, Any]]) -> int:
        if not factors:
            return 0

        normalized = []
        for f in factors:
            item = dict(f)
            item.setdefault("data_quality_flag", "COMPLETE")
            item.setdefault("metric_applicability_flag", "STANDARD_INDUSTRIAL")
            normalized.append(item)

        sql = """
        INSERT INTO fundamental_factors_daily (
            symbol, trading_date, close_price, shares_outstanding, market_cap_inr_crore,
            ttm_revenue, ttm_ebitda, ttm_ebit, ttm_net_profit, ttm_eps_adjusted,
            latest_equity, latest_debt, latest_cash, pe_ratio, pb_ratio, ps_ratio,
            ev_ebitda, dividend_yield_ttm, roe_pct, roce_pct, debt_to_equity,
            operating_margin_ttm, net_margin_ttm, revenue_growth_yoy, net_profit_growth_yoy,
            eps_growth_yoy, sector, sector_pe_median, pe_vs_sector_spread, pe_percentile_sector,
            valuation_decile_universe, statements_count_ttm, data_quality_flag,
            metric_applicability_flag, latest_statement_id, calculated_at
        ) VALUES (
            :symbol, :trading_date, :close_price, :shares_outstanding, :market_cap_inr_crore,
            :ttm_revenue, :ttm_ebitda, :ttm_ebit, :ttm_net_profit, :ttm_eps_adjusted,
            :latest_equity, :latest_debt, :latest_cash, :pe_ratio, :pb_ratio, :ps_ratio,
            :ev_ebitda, :dividend_yield_ttm, :roe_pct, :roce_pct, :debt_to_equity,
            :operating_margin_ttm, :net_margin_ttm, :revenue_growth_yoy, :net_profit_growth_yoy,
            :eps_growth_yoy, :sector, :sector_pe_median, :pe_vs_sector_spread, :pe_percentile_sector,
            :valuation_decile_universe, :statements_count_ttm, :data_quality_flag,
            :metric_applicability_flag, :latest_statement_id, :calculated_at
        )
        ON CONFLICT(symbol, trading_date) DO UPDATE SET
            close_price = excluded.close_price,
            shares_outstanding = excluded.shares_outstanding,
            market_cap_inr_crore = excluded.market_cap_inr_crore,
            ttm_revenue = excluded.ttm_revenue,
            ttm_ebitda = excluded.ttm_ebitda,
            ttm_ebit = excluded.ttm_ebit,
            ttm_net_profit = excluded.ttm_net_profit,
            ttm_eps_adjusted = excluded.ttm_eps_adjusted,
            latest_equity = excluded.latest_equity,
            latest_debt = excluded.latest_debt,
            latest_cash = excluded.latest_cash,
            pe_ratio = excluded.pe_ratio,
            pb_ratio = excluded.pb_ratio,
            ps_ratio = excluded.ps_ratio,
            ev_ebitda = excluded.ev_ebitda,
            dividend_yield_ttm = excluded.dividend_yield_ttm,
            roe_pct = excluded.roe_pct,
            roce_pct = excluded.roce_pct,
            debt_to_equity = excluded.debt_to_equity,
            operating_margin_ttm = excluded.operating_margin_ttm,
            net_margin_ttm = excluded.net_margin_ttm,
            revenue_growth_yoy = excluded.revenue_growth_yoy,
            net_profit_growth_yoy = excluded.net_profit_growth_yoy,
            eps_growth_yoy = excluded.eps_growth_yoy,
            sector = excluded.sector,
            sector_pe_median = excluded.sector_pe_median,
            pe_vs_sector_spread = excluded.pe_vs_sector_spread,
            pe_percentile_sector = excluded.pe_percentile_sector,
            valuation_decile_universe = excluded.valuation_decile_universe,
            statements_count_ttm = excluded.statements_count_ttm,
            data_quality_flag = excluded.data_quality_flag,
            metric_applicability_flag = excluded.metric_applicability_flag,
            latest_statement_id = excluded.latest_statement_id,
            calculated_at = excluded.calculated_at;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def get_fundamental_factors_daily(
        self,
        symbol: Optional[str] = None,
        trading_date: Optional[str] = None,
        sector: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM fundamental_factors_daily WHERE 1=1"
        params: List[Any] = []
        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        if trading_date:
            query += " AND trading_date = ?"
            params.append(trading_date)
        if sector:
            query += " AND sector = ?"
            params.append(sector)
        query += " ORDER BY trading_date ASC, symbol ASC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def update_index_valuation(
        self,
        index_name: str,
        trading_date: str,
        pe_ratio: Optional[float] = None,
        pb_ratio: Optional[float] = None,
        div_yield: Optional[float] = None
    ) -> int:
        """Updates official published index valuation ratios on index_daily."""
        sql = """
        UPDATE index_daily
        SET pe_ratio = ?, pb_ratio = ?, div_yield = ?
        WHERE index_name = ? AND trading_date = ?;
        """
        with self.get_connection() as conn:
            cursor = conn.execute(sql, (pe_ratio, pb_ratio, div_yield, index_name, trading_date))
            return cursor.rowcount

    def upsert_evidence_records(self, records: List[Dict[str, Any]]) -> int:
        """
        Upserts normalized evidence records into evidence_records table.
        """
        if not records:
            return 0
        sql = """
        INSERT INTO evidence_records (
            evidence_id, symbol, entity_type, event_date, broadcast_timestamp,
            effective_session_date, evidence_tier, evidence_category,
            evidence_direction, headline, details_json, source_identity,
            source_reference, verification_status, is_pit_eligible,
            reporting_basis, expectation_surprise, is_contradictory,
            retrieval_timestamp, created_at
        ) VALUES (
            :evidence_id, :symbol, :entity_type, :event_date, :broadcast_timestamp,
            :effective_session_date, :evidence_tier, :evidence_category,
            :evidence_direction, :headline, :details_json, :source_identity,
            :source_reference, :verification_status, :is_pit_eligible,
            :reporting_basis, :expectation_surprise, :is_contradictory,
            :retrieval_timestamp, :created_at
        )
        ON CONFLICT(evidence_id) DO UPDATE SET
            symbol = excluded.symbol,
            entity_type = excluded.entity_type,
            event_date = excluded.event_date,
            broadcast_timestamp = excluded.broadcast_timestamp,
            effective_session_date = excluded.effective_session_date,
            evidence_tier = excluded.evidence_tier,
            evidence_category = excluded.evidence_category,
            evidence_direction = excluded.evidence_direction,
            headline = excluded.headline,
            details_json = excluded.details_json,
            source_identity = excluded.source_identity,
            source_reference = excluded.source_reference,
            verification_status = excluded.verification_status,
            is_pit_eligible = excluded.is_pit_eligible,
            reporting_basis = excluded.reporting_basis,
            expectation_surprise = excluded.expectation_surprise,
            is_contradictory = excluded.is_contradictory,
            retrieval_timestamp = excluded.retrieval_timestamp;
            -- Note: created_at is strictly preserved from original insert on conflict
        """
        normalized = []
        for r in records:
            item = dict(r)
            if "tier" in item and "evidence_tier" not in item:
                item["evidence_tier"] = int(item["tier"])
            if "category" in item and "evidence_category" not in item:
                item["evidence_category"] = str(item["category"])
            if "direction" in item and "evidence_direction" not in item:
                item["evidence_direction"] = str(item["direction"])
            if isinstance(item.get("details_json"), dict):
                item["details_json"] = json.dumps(item["details_json"])
            elif "details" in item and "details_json" not in item:
                item["details_json"] = json.dumps(item["details"])
            normalized.append(item)

        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def get_evidence_records(
        self,
        symbol: Optional[str] = None,
        effective_session_date: Optional[str] = None,
        as_of_date: Optional[str] = None,
        tier: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Retrieves normalized evidence records filtered by symbol, session, as_of_date, and tier."""
        query = "SELECT * FROM evidence_records WHERE 1=1"
        params: List[Any] = []
        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        if effective_session_date:
            query += " AND effective_session_date = ?"
            params.append(effective_session_date)
        if as_of_date:
            query += " AND effective_session_date <= ?"
            params.append(as_of_date)
        if tier is not None:
            query += " AND evidence_tier = ?"
            params.append(tier)
        query += " ORDER BY effective_session_date DESC, evidence_tier ASC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            rows = []
            for r in cursor.fetchall():
                d = dict(r)
                if "evidence_tier" in d:
                    d["tier"] = d["evidence_tier"]
                if "evidence_category" in d:
                    d["category"] = d["evidence_category"]
                if "evidence_direction" in d:
                    d["direction"] = d["evidence_direction"]
                if d.get("details_json"):
                    try:
                        d["details"] = json.loads(d["details_json"])
                    except Exception:
                        d["details"] = {}
                rows.append(d)
            return rows

    def record_movement_explanation(self, explanation: Dict[str, Any]) -> None:
        """Records or updates a structured movement explanation run."""
        sql = """
        INSERT INTO movement_explanations (
            explanation_id, symbol, trading_date, movement_classification,
            stock_return_1d, benchmark_return_1d, sector_return_1d,
            sector_benchmark_type, sector_benchmark_name, abnormal_return,
            sector_adjusted_return, volume_ratio, primary_evidence_id,
            evidence_strength_score, confidence_level, is_contradicted,
            contradiction_penalty, unexplained_residual_pct, full_report_json,
            generated_at
        ) VALUES (
            :explanation_id, :symbol, :trading_date, :movement_classification,
            :stock_return_1d, :benchmark_return_1d, :sector_return_1d,
            :sector_benchmark_type, :sector_benchmark_name, :abnormal_return,
            :sector_adjusted_return, :volume_ratio, :primary_evidence_id,
            :evidence_strength_score, :confidence_level, :is_contradicted,
            :contradiction_penalty, :unexplained_residual_pct, :full_report_json,
            :generated_at
        )
        ON CONFLICT(explanation_id) DO UPDATE SET
            symbol = excluded.symbol,
            trading_date = excluded.trading_date,
            movement_classification = excluded.movement_classification,
            stock_return_1d = excluded.stock_return_1d,
            benchmark_return_1d = excluded.benchmark_return_1d,
            sector_return_1d = excluded.sector_return_1d,
            sector_benchmark_type = excluded.sector_benchmark_type,
            sector_benchmark_name = excluded.sector_benchmark_name,
            abnormal_return = excluded.abnormal_return,
            sector_adjusted_return = excluded.sector_adjusted_return,
            volume_ratio = excluded.volume_ratio,
            primary_evidence_id = excluded.primary_evidence_id,
            evidence_strength_score = excluded.evidence_strength_score,
            confidence_level = excluded.confidence_level,
            is_contradicted = excluded.is_contradicted,
            contradiction_penalty = excluded.contradiction_penalty,
            unexplained_residual_pct = excluded.unexplained_residual_pct,
            full_report_json = excluded.full_report_json,
            generated_at = excluded.generated_at;
        """
        item = dict(explanation)
        if isinstance(item.get("full_report_json"), dict):
            item["full_report_json"] = json.dumps(item["full_report_json"])
        with self.get_connection() as conn:
            conn.execute(sql, item)

    def get_movement_explanation(self, symbol: str, trading_date: str) -> Optional[Dict[str, Any]]:
        """Fetches a cached movement explanation by symbol and trading date."""
        sql = "SELECT * FROM movement_explanations WHERE symbol = ? AND trading_date = ? LIMIT 1;"
        with self.get_connection() as conn:
            cursor = conn.execute(sql, (symbol, trading_date))
            row = cursor.fetchone()
            if not row:
                return None
            d = dict(row)
            if d.get("full_report_json"):
                try:
                    d["full_report"] = json.loads(d["full_report_json"])
                except Exception:
                    d["full_report"] = {}
            return d

