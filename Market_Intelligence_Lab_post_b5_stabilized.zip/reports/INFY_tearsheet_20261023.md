# Company Research Tearsheet — INFY (Infosys Ltd.)
**As-of Trading Session:** `2026-10-23` | **Generated:** `2026-11-01 15:21:36 UTC`  
**ISIN:** `INE009A01021` | **Industry:** `Information Technology` | **Sector:** `Information Technology`  
**System Status:** Local-First SQLite Research Lab | **Execution Capabilities:** Permanently Disabled  

---

## 1. Executive Summary & Verified Empirical Facts

| Metric | Observed Value | Verification Status / Source Reference |
| :--- | :---: | :--- |
| **Closing Price (NSE)** | **₹1,153.80** | Primary CM-UDiFF Common Bhavcopy settlement |
| **Day's OHLC Range** | ₹1,038.05 – ₹1,197.80 | Open: ₹1,187.00 |
| **Day's Traded Volume** | 33,044,499 shares | Exchange turnover settlement |
| **Delivery Quantity** | *Unavailable in CM-UDiFF (Stored as NULL)* | Strict null preservation rule |
| **52-Week Range** | ₹980.40 – ₹1,728.00 | Trailing 245-session extreme closes |
| **52-Week Position** | **`23.2%`** | Position between 52w low (0%) and 52w high (100%) |

### 1.1 Verified Corporate Disclosures & Financial Results Metadata

| Disclosure ID | Effective Session | Category | Audit Status | Key Operational / Financial Fact | Direct Document URL |
| :--- | :---: | :---: | :---: | :--- | :--- |
| `INFY_DISC_20260915_BM_INTIMATION` | `2026-09-16` | `BOARD_MEETING_SCHEDULE` | `N/A` | Official intimation (Ref: SE Intimation_Q2FY27) that a meeti... (**`VERIFIED`**) | [Official Document PDF](https://www.infosys.com/investors/documents/exchange-filings/2026/notice-board-meeting-15sep2026.pdf) |
| `INFY_DISC_20261015_SCHED` | `2026-10-16` | `BOARD_MEETING_SCHEDULE` | `N/A` | Claimed board meeting schedule notice on Oct 15, 2026. Excha... (⚠️ **`SOURCE_UNVERIFIED`**) | [Search exchange announcements — source unverified](https://www.nseindia.com/companies-listing/corporate-filings-announcements) |
| `INFY_DISC_20261023_Q2` | `2026-10-26` | `EARNINGS` | `AUDITED` | Margin: `21.0%` | Dividend: `₹26.00/sh` | CC YoY: `+1.5%` | Reported YoY: `+10.7%` (**`VERIFIED`**) | [Official Document PDF](https://www.infosys.com/investors/documents/exchange-filings/2026/outcome-board-meeting23oct2026.pdf) |

> [!IMPORTANT]
> **Financial Field Integrity**: Revenue growth is separated into Constant Currency (+1.5% YoY, +1.2% QoQ) and Reported INR (+10.7% YoY) to prevent metric cross-contamination. Both standalone and consolidated financial statements are confirmed AUDITED.

## 2. Deterministic Quantitative Analytics

### 2.1 Multi-Horizon Trailing Returns (Split/Bonus Adjusted)

| Horizon | Trading Days | Stock Return | Benchmark (Nifty 50 PRI) | Excess Return vs Benchmark |
| :---: | :---: | :---: | :---: | :---: |
| **1-Day (1D)** | 1 | `+0.04%` | `-0.39%` | **`+0.43%`** |
| **1-Month (1M)** | 21 | `+12.08%` | `-3.12%` | **`+15.21%`** |
| **3-Month (3M)** | 63 | `+10.16%` | `-5.32%` | **`+15.48%`** |
| **6-Month (6M)** | 126 | `-9.05%` | `-7.29%` | **`-1.76%`** |
| **1-Year (1Y)** | 245 | `-23.31%` | `-12.96%` | **`-10.35%`** |

> [!NOTE]
> **Return Horizon Methodology**: Trailing returns use fixed trading-session windows (1D = 1 trading session, 1M = 21 trading sessions, 3M = 63 trading sessions, 6M = 126 trading sessions, 1Y = 245 trading sessions), ensuring exact reproducibility across holidays and suspensions.


### 2.2 Moving Averages, Volatility & Risk Metrics

| Quantitative Metric | Value | Reference / Formula |
| :--- | :---: | :--- |
| **20-Day SMA** | ₹1,057.82 | Distance: **`+9.07%`** |
| **50-Day SMA** | ₹1,085.11 | Distance: **`+6.33%`** |
| **200-Day SMA** | ₹1,227.04 | Distance: **`-5.97%`** |
| **20-Day Annualized Volatility** | `36.26%` | Annualized standard deviation ($\sigma \times \sqrt{252}$) |
| **60-Day Rolling Beta (Nifty 50)** | **`1.07`** | OLS slope $\beta = \mathrm{Cov}(R_s, R_b) / \mathrm{Var}(R_b)$ |
| **20-Day Volume Ratio (VR 20)** | `2.43x` | Today Volume / 20-Day ADV (VR >= 2.5x threshold) |
| **50-Day Volume Z-Score ($Z_V$)** | `+4.46σ` | Normalized volume anomaly ($Z \ge 2.5\sigma$ threshold) |


## 3. Sector & Peer Relative Strength (IT Peers)

| Peer Symbol | Latest Close | 1-Month Return | 3-Month Return | Excess vs INFY (1M) | Excess vs INFY (3M) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **INFY (Target)** | **₹1,153.80** | **`+12.08%`** | **`+10.16%`** | *Base* | *Base* |
| **TCS** | ₹2,530.00 | `+20.19%` | `+12.80%` | `+8.11%` | `+2.64%` |
| **HCLTECH** | ₹1,422.20 | `+11.95%` | `+14.26%` | `-0.14%` | `+4.10%` |
| **TECHM** | ₹1,790.00 | `+15.36%` | `+15.05%` | `+3.28%` | `+4.89%` |


## 4. Econometric Event Studies & Disclosures Audit

| Event ID / Disclosure | Event Session $t=0$ | Estimation Window | Abnormal Return $AR_0$ | $CAR[-1, +1]$ | $t$-stat ($p$-value) | Study Status & Guardrails |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| `INFY_DISC_20260915_BM_INTIMATION` | `2026-09-16` | `2025-09-04` to `2026-08-17` | `-1.81%` | **`+2.76%`** | `t=0.87 (p=0.3822)` | ❌ Not Significant (p>0.05) |
| `INFY_DISC_20261015_SCHED` | `2026-10-16` | `2025-10-06` to `2026-09-16` | `+4.23%` | **`+3.42%`** | `t=1.06 (p=0.2884)` | ❌ Not Significant (p>0.05) |
| `INFY_DISC_20261023_Q2` | `2026-10-26` | `[-252, -21]` | `N/A` | `N/A` | `N/A` | ⏳ **`AWAITING_POST_EVENT_DATA`** |

### 4.1 Epistemic Guardrails & Provenance Warnings

1. **`INFY_DISC_20260915_BM_INTIMATION` (Verified Board Meeting Notice)**: Intimation of board meeting under SEBI Reg 29. CAR[-1, +1] was +2.76% ($p=0.3822$), failing the 5% significance threshold. Co-occurring movements reflect general market variance rather than fundamental information re-pricing.
2. **`INFY_DISC_20261015_SCHED` (Flagged Event)**: ⚠️ **`SOURCE_UNVERIFIED`**. Regulatory circular audit confirms no exchange filing occurred on Oct 15, 2026. This record is quarantined and must NOT be cited as a verified corporate disclosure.
3. **`INFY_DISC_20261023_Q2` (Actual Q2 Results)**: ⏳ **`AWAITING_POST_EVENT_DATA`**. Broadcast occurred Friday post-market (16:30 IST), shifting effective session $t=0$ to Monday, October 26, 2026. Because our local settled dataset ends on Friday, October 23, 2026, the study is properly gated. Zero synthetic returns are manufactured.


## 5. Corporate Action Ledger & Downstream Protection

| Action Type | Ex-Date | Record Date | Purpose & Rate | Adjustment Factor | Historical Return Impact |
| :---: | :---: | :---: | :--- | :---: | :--- |
| `DIVIDEND` | `2024-10-29` | `*Historical Ex-Date Basis*` | Interim Dividend - Rs 21 Per Share | `1.0` | Mode 2 Total Return Eligible |
| `DIVIDEND` | `2025-05-30` | `*Historical Ex-Date Basis*` | Dividend - Rs 22 Per Share | `1.0` | Mode 2 Total Return Eligible |
| `DIVIDEND` | `2025-10-27` | `*Historical Ex-Date Basis*` | Interim Dividend - Rs 23 Per Share | `1.0` | Mode 2 Total Return Eligible |
| `OTHER` | `2025-11-14` | `*Historical Ex-Date Basis*` | Buy Back | `1.0` | Mode 2 Total Return Eligible |
| `DIVIDEND` | `2026-06-10` | `*Historical Ex-Date Basis*` | Dividend - Rs 25 Per Share | `1.0` | Mode 2 Total Return Eligible |

> [!NOTE]
> **Future Dividend Quarantine**: The newly announced ₹26.00 interim dividend (Record Date: Nov 3, 2026) is quarantined in `corporate_disclosures`. It will NOT be entered into `corporate_actions` until the ex-date actually trades, protecting historical Mode 2 holding-period calculations from premature dividend crediting.

## 6. Explanatory Hypotheses & Scenario Projections

1. **Trend & Momentum Hypothesis**: INFY is currently positioned at `23.2%` of its 52-week range, trading `+9.07%` relative to its 20-day SMA and `-5.97%` relative to its 200-day SMA. This structural positioning indicates an ongoing intermediate consolidation phase following broad IT sector re-rating.
2. **Downside Risk Scenario**: In the event that post-market Q2 constant-currency revenue growth (+1.5% YoY) and revised FY27 CC revenue guidance (trimmed to 1%–2%) disappoint institutional market participants upon market open on Monday, October 26, 2026, initial technical support resides near the 52-week trough of ₹980.40.
3. **Upside Rebound Scenario**: Conversely, should the 21.0% operating margin resilience, $5.2B large deal wins, and enhanced ₹26/share interim dividend trigger institutional accumulation, immediate overhead resistance aligns with the 50-day SMA (₹1,085.11) and 200-day SMA (₹1,227.04).

> [!CAUTION]
> **Epistemic Limitation**: All hypotheses and scenarios are probabilistic qualitative frameworks generated for quantitative research. They do not constitute financial advice, trade recommendations, or causal certainty. Live order placement is permanently disabled.
