import sqlite3
import os
import json
from typing import List, Dict, Any, Optional

class DatabaseManager:
    """Manages SQLite database connections, additive schema migrations, and transactional persistence."""

    def __init__(self, db_path: str = "data/market_lab.db"):
        self.db_path = db_path
        self._mem_conn: Optional[sqlite3.Connection] = None
        if self.db_path == ":memory:":
            self._mem_conn = sqlite3.connect(":memory:")
            self._mem_conn.row_factory = sqlite3.Row
        else:
            os.makedirs(os.path.dirname(os.path.abspath(self.db_path)), exist_ok=True)
        self.init_schema()

    def get_connection(self) -> sqlite3.Connection:
        if self._mem_conn is not None:
            return self._mem_conn
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA journal_mode = WAL;")
        return conn

    def init_schema(self) -> None:
        """Applies base Phase 1 schema, Phase 2 migration, and safe column alterations."""
        schema_dir = os.path.dirname(__file__)
        schema_v1_path = os.path.join(schema_dir, "schema.sql")
        schema_v2_path = os.path.join(schema_dir, "schema_v2.sql")

        with self.get_connection() as conn:
            # 1. Base Phase 1 Schema
            if os.path.exists(schema_v1_path):
                with open(schema_v1_path, "r", encoding="utf-8") as f:
                    conn.executescript(f.read())

            # 2. Safe additive column alterations on ohlcv_daily
            cursor = conn.execute("PRAGMA table_info(ohlcv_daily);")
            existing_cols = {row["name"] for row in cursor.fetchall()}
            if "trades_count" not in existing_cols:
                conn.execute("ALTER TABLE ohlcv_daily ADD COLUMN trades_count INTEGER DEFAULT NULL;")
            if "data_status" not in existing_cols:
                conn.execute("ALTER TABLE ohlcv_daily ADD COLUMN data_status TEXT NOT NULL DEFAULT 'final_settled';")

            # 3. Phase 2 Schema Extension
            if os.path.exists(schema_v2_path):
                with open(schema_v2_path, "r", encoding="utf-8") as f:
                    conn.executescript(f.read())

            # 4. Safe additive column alterations on corporate_disclosures
            cursor = conn.execute("PRAGMA table_info(corporate_disclosures);")
            disc_cols = {row["name"] for row in cursor.fetchall()}
            if disc_cols:
                if "verification_status" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN verification_status TEXT NOT NULL DEFAULT 'PENDING_VERIFICATION';")
                if "audit_status" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN audit_status TEXT DEFAULT NULL;")
                if "dividend_declared" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN dividend_declared REAL DEFAULT NULL;")
                if "operating_margin_pct" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN operating_margin_pct REAL DEFAULT NULL;")
                if "revenue_inr_crore" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_inr_crore REAL DEFAULT NULL;")
                if "revenue_growth_yoy_cc" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_growth_yoy_cc REAL DEFAULT NULL;")
                if "revenue_growth_qoq_cc" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_growth_qoq_cc REAL DEFAULT NULL;")
                if "revenue_growth_yoy_reported" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN revenue_growth_yoy_reported REAL DEFAULT NULL;")
                if "source_timestamp_basis" not in disc_cols:
                    conn.execute("ALTER TABLE corporate_disclosures ADD COLUMN source_timestamp_basis TEXT DEFAULT NULL;")

    def upsert_ohlcv_records(self, records: List[Dict[str, Any]]) -> int:
        """
        Upserts validated OHLCV records.
        Unavailable fields (such as delivery_qty or trades_count) are stored as NULL.
        """
        if not records:
            return 0

        # Normalize optional fields so sqlite3 binding parameters are never missing
        normalized = []
        for r in records:
            item = dict(r)
            if "ltp" not in item:
                item["ltp"] = None
            if "prev_close" not in item:
                item["prev_close"] = None
            if "turnover" not in item:
                item["turnover"] = None
            if "delivery_qty" not in item:
                item["delivery_qty"] = None
            if "trades_count" not in item:
                item["trades_count"] = None
            if "data_status" not in item:
                item["data_status"] = "final_settled"
            normalized.append(item)

        sql = """
        INSERT INTO ohlcv_daily (
            symbol, trading_date, series, open, high, low, close,
            ltp, prev_close, volume, turnover, delivery_qty,
            source, retrieval_timestamp, trades_count, data_status
        ) VALUES (
            :symbol, :trading_date, :series, :open, :high, :low, :close,
            :ltp, :prev_close, :volume, :turnover, :delivery_qty,
            :source, :retrieval_timestamp, :trades_count, :data_status
        )
        ON CONFLICT(symbol, trading_date, series) DO UPDATE SET
            open = excluded.open,
            high = excluded.high,
            low = excluded.low,
            close = excluded.close,
            ltp = excluded.ltp,
            prev_close = excluded.prev_close,
            volume = excluded.volume,
            turnover = excluded.turnover,
            delivery_qty = excluded.delivery_qty,
            source = excluded.source,
            retrieval_timestamp = excluded.retrieval_timestamp,
            trades_count = excluded.trades_count,
            data_status = excluded.data_status
        WHERE ohlcv_daily.data_status != 'final_settled' OR excluded.data_status = 'final_settled';
        """

        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def upsert_corporate_actions(self, actions: List[Dict[str, Any]]) -> int:
        if not actions:
            return 0

        sql = """
        INSERT INTO corporate_actions (
            symbol, action_type, ex_date, record_date, purpose,
            adjustment_factor, source, retrieval_timestamp
        ) VALUES (
            :symbol, :action_type, :ex_date, :record_date, :purpose,
            :adjustment_factor, :source, :retrieval_timestamp
        )
        ON CONFLICT(symbol, action_type, ex_date) DO UPDATE SET
            record_date = excluded.record_date,
            purpose = excluded.purpose,
            adjustment_factor = excluded.adjustment_factor,
            source = excluded.source,
            retrieval_timestamp = excluded.retrieval_timestamp;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, actions)
            return cursor.rowcount

    def record_audit_log(
        self,
        source: str,
        endpoint: str,
        symbol: str,
        date_range_start: Optional[str],
        date_range_end: Optional[str],
        records_retrieved: int,
        records_accepted: int,
        records_rejected: int,
        validation_summary: Dict[str, Any],
        raw_payload_path: str,
        status: str,
        created_at: str
    ) -> int:
        sql = """
        INSERT INTO ingestion_audit_log (
            source, endpoint, symbol, date_range_start, date_range_end,
            records_retrieved, records_accepted, records_rejected,
            validation_summary, raw_payload_path, status, created_at
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        );
        """
        with self.get_connection() as conn:
            cursor = conn.execute(sql, (
                source, endpoint, symbol, date_range_start, date_range_end,
                records_retrieved, records_accepted, records_rejected,
                json.dumps(validation_summary), raw_payload_path, status, created_at
            ))
            return cursor.lastrowid

    def get_stock_history(
        self,
        symbol: str,
        series: str = "EQ",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM ohlcv_daily WHERE symbol = ? AND series = ?"
        params: List[Any] = [symbol, series]

        if start_date:
            query += " AND trading_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND trading_date <= ?"
            params.append(end_date)

        query += " ORDER BY trading_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_corporate_actions(
        self,
        symbol: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM corporate_actions WHERE symbol = ?"
        params: List[Any] = [symbol]

        if start_date:
            query += " AND ex_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND ex_date <= ?"
            params.append(end_date)

        query += " ORDER BY ex_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    # -------------------------------------------------------------
    # Phase 2 Extension Methods
    # -------------------------------------------------------------

    def upsert_securities_master(self, securities: List[Dict[str, Any]]) -> int:
        if not securities:
            return 0
        sql = """
        INSERT INTO securities_master (
            symbol, company_name, isin, industry, sector, macro_sector, listing_date, is_active, updated_at
        ) VALUES (
            :symbol, :company_name, :isin, :industry, :sector, :macro_sector, :listing_date, :is_active, :updated_at
        )
        ON CONFLICT(symbol) DO UPDATE SET
            company_name = excluded.company_name,
            isin = excluded.isin,
            industry = excluded.industry,
            sector = excluded.sector,
            macro_sector = excluded.macro_sector,
            listing_date = excluded.listing_date,
            is_active = excluded.is_active,
            updated_at = excluded.updated_at;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, securities)
            return cursor.rowcount

    def get_securities_master(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        query = "SELECT * FROM securities_master"
        params: List[Any] = []
        if symbol:
            query += " WHERE symbol = ?"
            params.append(symbol)
        query += " ORDER BY symbol ASC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def upsert_index_membership_history(self, records: List[Dict[str, Any]]) -> int:
        if not records:
            return 0
        sql = """
        INSERT INTO index_membership_history (
            symbol, index_name, valid_from, valid_to, is_verified_historical, source, retrieved_at
        ) VALUES (
            :symbol, :index_name, :valid_from, :valid_to, :is_verified_historical, :source, :retrieved_at
        )
        ON CONFLICT(symbol, index_name, valid_from) DO UPDATE SET
            valid_to = excluded.valid_to,
            is_verified_historical = excluded.is_verified_historical,
            source = excluded.source,
            retrieved_at = excluded.retrieved_at;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, records)
            return cursor.rowcount

    def get_index_constituents(self, index_name: str, as_of_date: str) -> Dict[str, Any]:
        """
        Retrieves point-in-time index constituents as of a given date.
        Detects whether any returned constituent uses unverified proxy membership.
        """
        sql = """
        SELECT symbol, is_verified_historical, source
        FROM index_membership_history
        WHERE index_name = ?
          AND valid_from <= ?
          AND (valid_to IS NULL OR valid_to > ?)
        ORDER BY symbol ASC;
        """
        with self.get_connection() as conn:
            cursor = conn.execute(sql, (index_name, as_of_date, as_of_date))
            rows = [dict(r) for r in cursor.fetchall()]

        if not rows:
            return {
                "index_name": index_name,
                "as_of_date": as_of_date,
                "count": 0,
                "constituents": [],
                "is_survivorship_bias_free": False,
                "membership_basis": "empty_or_unindexed",
                "warning": f"No constituents indexed for {index_name} as of {as_of_date}."
            }

        symbols = [r["symbol"] for r in rows]
        all_verified = all(r["is_verified_historical"] == 1 for r in rows)
        membership_basis = "survivorship_bias_free" if all_verified else "current_proxy_unadjusted"
        warning = None
        if not all_verified:
            warning = (
                f"Historical index membership for {index_name} on {as_of_date} contains proxy observations "
                "(membership_basis: current_proxy_unadjusted). Results may exhibit survivorship bias."
            )

        return {
            "index_name": index_name,
            "as_of_date": as_of_date,
            "count": len(symbols),
            "constituents": symbols,
            "is_survivorship_bias_free": all_verified,
            "membership_basis": membership_basis,
            "warning": warning
        }

    def upsert_index_daily(self, records: List[Dict[str, Any]]) -> int:
        """
        Upserts daily index series.
        For TRI records, open, high, and low are stored as NULL (None), never fabricated.
        """
        if not records:
            return 0

        normalized = []
        for r in records:
            item = dict(r)
            if "open" not in item:
                item["open"] = None
            if "high" not in item:
                item["high"] = None
            if "low" not in item:
                item["low"] = None
            if "volume" not in item:
                item["volume"] = None
            if "pe_ratio" not in item:
                item["pe_ratio"] = None
            if "pb_ratio" not in item:
                item["pb_ratio"] = None
            if "div_yield" not in item:
                item["div_yield"] = None
            normalized.append(item)

        sql = """
        INSERT INTO index_daily (
            index_name, trading_date, index_type, open, high, low, close,
            volume, pe_ratio, pb_ratio, div_yield, source, retrieval_timestamp
        ) VALUES (
            :index_name, :trading_date, :index_type, :open, :high, :low, :close,
            :volume, :pe_ratio, :pb_ratio, :div_yield, :source, :retrieval_timestamp
        )
        ON CONFLICT(index_name, trading_date, index_type) DO UPDATE SET
            open = excluded.open,
            high = excluded.high,
            low = excluded.low,
            close = excluded.close,
            volume = excluded.volume,
            pe_ratio = excluded.pe_ratio,
            pb_ratio = excluded.pb_ratio,
            div_yield = excluded.div_yield,
            source = excluded.source,
            retrieval_timestamp = excluded.retrieval_timestamp;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def get_index_history(
        self,
        index_name: str,
        index_type: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM index_daily WHERE index_name = ? AND index_type = ?"
        params: List[Any] = [index_name, index_type.upper()]

        if start_date:
            query += " AND trading_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND trading_date <= ?"
            params.append(end_date)

        query += " ORDER BY trading_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def upsert_quant_factors(self, factors: List[Dict[str, Any]]) -> int:
        """
        Upserts calculated daily quantitative factors.
        Rolling factors with incomplete warm-up windows are permitted as NULL.
        """
        if not factors:
            return 0
        sql = """
        INSERT INTO quant_factors_daily (
            symbol, trading_date, ret_1d, ret_5d, ret_20d, vol_20d_annualized,
            sma_20, sma_50, sma_200, beta_60d_nifty, volume_ratio_20d,
            volume_zscore_50d, volume_log_zscore_50d, is_volume_spike_ratio,
            is_volume_spike_zscore, distance_52w_high, distance_52w_low
        ) VALUES (
            :symbol, :trading_date, :ret_1d, :ret_5d, :ret_20d, :vol_20d_annualized,
            :sma_20, :sma_50, :sma_200, :beta_60d_nifty, :volume_ratio_20d,
            :volume_zscore_50d, :volume_log_zscore_50d, :is_volume_spike_ratio,
            :is_volume_spike_zscore, :distance_52w_high, :distance_52w_low
        )
        ON CONFLICT(symbol, trading_date) DO UPDATE SET
            ret_1d = excluded.ret_1d,
            ret_5d = excluded.ret_5d,
            ret_20d = excluded.ret_20d,
            vol_20d_annualized = excluded.vol_20d_annualized,
            sma_20 = excluded.sma_20,
            sma_50 = excluded.sma_50,
            sma_200 = excluded.sma_200,
            beta_60d_nifty = excluded.beta_60d_nifty,
            volume_ratio_20d = excluded.volume_ratio_20d,
            volume_zscore_50d = excluded.volume_zscore_50d,
            volume_log_zscore_50d = excluded.volume_log_zscore_50d,
            is_volume_spike_ratio = excluded.is_volume_spike_ratio,
            is_volume_spike_zscore = excluded.is_volume_spike_zscore,
            distance_52w_high = excluded.distance_52w_high,
            distance_52w_low = excluded.distance_52w_low;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, factors)
            return cursor.rowcount

    def get_quant_factors(
        self,
        symbol: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM quant_factors_daily WHERE symbol = ?"
        params: List[Any] = [symbol]

        if start_date:
            query += " AND trading_date >= ?"
            params.append(start_date)
        if end_date:
            query += " AND trading_date <= ?"
            params.append(end_date)

        query += " ORDER BY trading_date ASC;"

        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def upsert_corporate_disclosures(self, disclosures: List[Dict[str, Any]]) -> int:
        if not disclosures:
            return 0

        normalized = []
        for d in disclosures:
            item = dict(d)
            if "verification_status" not in item or not item["verification_status"]:
                item["verification_status"] = "PENDING_VERIFICATION"
            if "audit_status" not in item:
                item["audit_status"] = None
            if "dividend_declared" not in item:
                item["dividend_declared"] = None
            if "operating_margin_pct" not in item:
                item["operating_margin_pct"] = None
            if "revenue_inr_crore" not in item:
                item["revenue_inr_crore"] = None
            if "revenue_growth_yoy_cc" not in item:
                item["revenue_growth_yoy_cc"] = None
            if "revenue_growth_qoq_cc" not in item:
                item["revenue_growth_qoq_cc"] = None
            if "revenue_growth_yoy_reported" not in item:
                item["revenue_growth_yoy_reported"] = None
            if "source_timestamp_basis" not in item:
                item["source_timestamp_basis"] = None
            normalized.append(item)

        sql = """
        INSERT INTO corporate_disclosures (
            disclosure_id, symbol, broadcast_timestamp, effective_session_date,
            category, subject, details_summary, source_url, retrieval_timestamp,
            verification_status, audit_status, dividend_declared, operating_margin_pct,
            revenue_inr_crore, revenue_growth_yoy_cc, revenue_growth_qoq_cc,
            revenue_growth_yoy_reported, source_timestamp_basis
        ) VALUES (
            :disclosure_id, :symbol, :broadcast_timestamp, :effective_session_date,
            :category, :subject, :details_summary, :source_url, :retrieval_timestamp,
            :verification_status, :audit_status, :dividend_declared, :operating_margin_pct,
            :revenue_inr_crore, :revenue_growth_yoy_cc, :revenue_growth_qoq_cc,
            :revenue_growth_yoy_reported, :source_timestamp_basis
        )
        ON CONFLICT(disclosure_id) DO UPDATE SET
            symbol = excluded.symbol,
            broadcast_timestamp = excluded.broadcast_timestamp,
            effective_session_date = excluded.effective_session_date,
            category = excluded.category,
            subject = excluded.subject,
            details_summary = excluded.details_summary,
            source_url = excluded.source_url,
            retrieval_timestamp = excluded.retrieval_timestamp,
            verification_status = excluded.verification_status,
            audit_status = excluded.audit_status,
            dividend_declared = excluded.dividend_declared,
            operating_margin_pct = excluded.operating_margin_pct,
            revenue_inr_crore = excluded.revenue_inr_crore,
            revenue_growth_yoy_cc = excluded.revenue_growth_yoy_cc,
            revenue_growth_qoq_cc = excluded.revenue_growth_qoq_cc,
            revenue_growth_yoy_reported = excluded.revenue_growth_yoy_reported,
            source_timestamp_basis = excluded.source_timestamp_basis;
        """
        with self.get_connection() as conn:
            cursor = conn.executemany(sql, normalized)
            return cursor.rowcount

    def get_corporate_disclosures(
        self,
        symbol: Optional[str] = None,
        verification_status: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM corporate_disclosures"
        clauses = []
        params = []
        if symbol:
            clauses.append("symbol = ?")
            params.append(symbol)
        if verification_status:
            clauses.append("verification_status = ?")
            params.append(verification_status)
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        query += " ORDER BY effective_session_date ASC, broadcast_timestamp ASC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def record_event_study_result(self, result: Dict[str, Any]) -> int:
        sql = """
        INSERT INTO event_study_results (
            symbol, disclosure_id, event_date, estimation_window_start,
            estimation_window_end, model_alpha, model_beta, model_r2,
            ar_t0, car_minus1_plus1, car_0_plus2, t_stat, p_value,
            explanatory_hypothesis, calculated_at
        ) VALUES (
            :symbol, :disclosure_id, :event_date, :estimation_window_start,
            :estimation_window_end, :model_alpha, :model_beta, :model_r2,
            :ar_t0, :car_minus1_plus1, :car_0_plus2, :t_stat, :p_value,
            :explanatory_hypothesis, :calculated_at
        );
        """
        with self.get_connection() as conn:
            cursor = conn.execute(sql, result)
            return cursor.lastrowid

    def get_event_study_results(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        query = "SELECT * FROM event_study_results"
        params: List[Any] = []
        if symbol:
            query += " WHERE symbol = ?"
            params.append(symbol)
        query += " ORDER BY study_id DESC;"
        with self.get_connection() as conn:
            cursor = conn.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
